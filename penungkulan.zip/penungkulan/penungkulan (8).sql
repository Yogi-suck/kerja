-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Apr 2022 pada 07.08
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penungkulan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_anggota_kk`
--

CREATE TABLE `tbl_anggota_kk` (
  `nomer` int(10) NOT NULL,
  `no_kk` varchar(21) NOT NULL,
  `nik` varchar(21) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_anggota_kk`
--

INSERT INTO `tbl_anggota_kk` (`nomer`, `no_kk`, `nik`, `status`) VALUES
(1, '330133013399', '121212121212', 'aktif'),
(3, '121124242', '2321312313', 'aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kelahiran`
--

CREATE TABLE `tbl_kelahiran` (
  `no_kelahiran` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `nik` varchar(21) NOT NULL,
  `jenis_kelamin` varchar(9) NOT NULL,
  `hari` varchar(6) NOT NULL,
  `tanggal` varchar(2) NOT NULL,
  `jam` varchar(6) NOT NULL,
  `tempat` varchar(20) NOT NULL,
  `nik_ayah` varchar(21) NOT NULL,
  `nik_pelapor` varchar(21) NOT NULL,
  `hub_pelapor` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_kelahiran`
--

INSERT INTO `tbl_kelahiran` (`no_kelahiran`, `nama`, `nik`, `jenis_kelamin`, `hari`, `tanggal`, `jam`, `tempat`, `nik_ayah`, `nik_pelapor`, `hub_pelapor`) VALUES
(1, 'Herman', '331013001100001', 'Laki-Laki', 'Rabu', '02', '07:00', 'Yogyakarta', '331013001100002', '331013001100003', 'Ayah'),
(2, 'jinguk', '12345678', 'Laki-Laki', 'senin', '05', '18.40', 'penungkulan', 'prio', '323232323232323', 'ayah'),
(3, 'sisi', '234123456', 'Perempuan', 'senin', '20', '12.00', 'penungkulan', '333333333333', 'sasasa aaaaaaaaaa', 'ayah kandung'),
(4, 'aji', '333333333333', 'Laki Laki', 'senin', '20', '12.00', 'penungkulan', '333333333333', '333333333333', 'ayah kandung'),
(5, 'aji', '123234345', 'Perempuan', 'senin', '20', '12.00', 'penungkulan', '13131313', '13131313', 'ayah kandung'),
(6, 'asa', '667890456', 'Laki Laki', 'asas', '20', 'asa', 'aa', 'a', 'a', 'a'),
(7, 'zXZx', '243456467', 'Laki Laki', 'XZX', '20', 'ZXX', 'ZXZX', 'Xzxx', 'zXXZX', 'ZXzX'),
(14, 'wawan', '3300224567809', 'Laki Laki', 'senin', '20', '12.00', 'penungkulan', '331013001100002', '331013001100002', 'ayah kandung');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kematian`
--

CREATE TABLE `tbl_kematian` (
  `no_kematian` int(11) NOT NULL,
  `nik` varchar(21) NOT NULL,
  `hari` varchar(6) NOT NULL,
  `tanggal` varchar(2) NOT NULL,
  `tempat` varchar(20) NOT NULL,
  `penyebab` varchar(100) NOT NULL,
  `nik_pelapor` varchar(21) NOT NULL,
  `hub_pelapor` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_kematian`
--

INSERT INTO `tbl_kematian` (`no_kematian`, `nik`, `hari`, `tanggal`, `tempat`, `penyebab`, `nik_pelapor`, `hub_pelapor`) VALUES
(1, '3300224567809', 'senin', '20', 'penungkulan', 'kurang duit', '331013001100002', 'ayah kandung'),
(2, '1212121212', 'senin', '02', 'penungkulan', 'kecelakaan', '13131313', 'anak'),
(3, 'asw a', 'senin', '20', 'penungkulan', 'kurang duit', '1234567876', 'yang e'),
(4, '333333333333', 'senin', '20', 'penungkulan', 'kurang duit', '333333333333', 'ayah kandung');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kk`
--

CREATE TABLE `tbl_kk` (
  `no_kk` varchar(21) NOT NULL,
  `nik` varchar(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_kk`
--

INSERT INTO `tbl_kk` (`no_kk`, `nik`) VALUES
('1', '12121111');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pekerjaan`
--

CREATE TABLE `tbl_pekerjaan` (
  `kd_pekerjaan` varchar(3) NOT NULL,
  `nama_pekerjaan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_pekerjaan`
--

INSERT INTO `tbl_pekerjaan` (`kd_pekerjaan`, `nama_pekerjaan`) VALUES
('Mhs', 'Mahasiswa a'),
('PNS', 'Pegawai negeri sipil');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pendatang`
--

CREATE TABLE `tbl_pendatang` (
  `no_pendatang` int(100) NOT NULL,
  `nik` varchar(21) NOT NULL,
  `nik_kepala_keluarga` varchar(21) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `tanggal` varchar(10) NOT NULL,
  `alamat_asal` varchar(20) NOT NULL,
  `alamat_tujuan` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_pendatang`
--

INSERT INTO `tbl_pendatang` (`no_pendatang`, `nik`, `nik_kepala_keluarga`, `nama`, `tanggal`, `alamat_asal`, `alamat_tujuan`, `status`) VALUES
(1, '12121212', '1222111', '2022-02-09', '12122022', 'suwinong', 'sirembes', 'masyarakat aktif'),
(2, '123412121', '121213312', 'hasim', 'aassa', 'condong catur', 'maguwo', 'aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pendidikan`
--

CREATE TABLE `tbl_pendidikan` (
  `kd_pendidikan` varchar(3) NOT NULL,
  `nama_pendidikan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_pendidikan`
--

INSERT INTO `tbl_pendidikan` (`kd_pendidikan`, `nama_pendidikan`) VALUES
('SD', 'Sekolah Dasar'),
('SMP', 'Sekolah Menengah Per');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_penduduk`
--

CREATE TABLE `tbl_penduduk` (
  `id_penduduk` int(11) NOT NULL,
  `kk` varchar(21) NOT NULL,
  `nik` varchar(21) NOT NULL,
  `nama_penduduk` varchar(20) NOT NULL,
  `kd_perdukuhan` varchar(10) NOT NULL,
  `rt` varchar(2) NOT NULL,
  `rw` varchar(3) NOT NULL,
  `desa` varchar(10) NOT NULL,
  `kecamatan` varchar(7) NOT NULL,
  `kabupaten` varchar(7) NOT NULL,
  `provinsi` varchar(12) NOT NULL,
  `kodepos` varchar(5) NOT NULL,
  `tmptlahir` varchar(20) NOT NULL,
  `tgllahir` varchar(10) NOT NULL,
  `agama` varchar(8) NOT NULL,
  `statusperkawinan` varchar(12) NOT NULL,
  `statushubkeluarga` varchar(12) NOT NULL,
  `kd_pekerjaan` varchar(20) NOT NULL,
  `kd_pendidikan` varchar(20) NOT NULL,
  `gol_darah` varchar(2) DEFAULT NULL,
  `status_kewarganegaraan` varchar(20) NOT NULL,
  `jenis_kelamin` varchar(12) NOT NULL,
  `nama_ayah` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_penduduk`
--

INSERT INTO `tbl_penduduk` (`id_penduduk`, `kk`, `nik`, `nama_penduduk`, `kd_perdukuhan`, `rt`, `rw`, `desa`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `tmptlahir`, `tgllahir`, `agama`, `statusperkawinan`, `statushubkeluarga`, `kd_pekerjaan`, `kd_pendidikan`, `gol_darah`, `status_kewarganegaraan`, `jenis_kelamin`, `nama_ayah`) VALUES
(1, '00001', '333333333333', 'yogi a aaa', 'sirembes', '1', '1', 'Penungkula', 'Gebang', 'Purwore', 'Jawa Tengan', '54191', 'Purworejo', '', 'islam', 'Belum kawin', 'Kepala Kelua', 'mahasiswa', 'TAMAT SD / SEDERAJAT', 'A', 'indonesia', 'Laki-Laki', 'slamet andayani'),
(2, '', 'sasasa aaaaaaaaaa', 'asas asasa', 'suwinong', '3', '2', 'asas', 'asa', 'as', 'asas', 'asa', 'as', '2022-02-09', 'islam', 'Belum kawin', 'Kepala Kelua', 'asas', 'TAMAT SD / SEDERAJAT', 'A', 'asas', 'Perempuan', 'asaas'),
(3, '00001', '333333333333', 'yogi a asu', 'sirembes', '1', '1', 'Penungkula', 'Gebang', 'Purwore', 'Jawa Tengan', '54191', 'Purworejo', '', 'islam', 'Belum kawin', 'Kepala Kelua', 'mahasiswa', 'TAMAT SD / SEDERAJAT', 'A', 'indonesia', 'Laki-Laki', 'slamet andayani'),
(4, '001', '331013001100001', 'Herman', 'Sirembes', '02', '12', 'Penungkula', 'Rabu', 'Purwore', 'Rabu', '54161', 'Yogyakarta', '10/01/2000', 'Islam', 'Belum Kawin', 'Kepala Kelua', 'Mahasiswa', 'TAMAT SD / SEDERAJAT', 'A', 'Indonesia', 'Laki-Laki', 'Sudrajat'),
(5, '002', '331013001100002', 'Cumi', 'Sirembes', '03', '31', 'Penungkula', 'Senin', 'Purwore', 'Senin', '54812', 'Jakarta', '10/01/2000', 'Hindu', 'Belum Kawin', 'Kepala Kelua', 'Pelajar', 'TAMAT SD / SEDERAJAT', 'A', 'Indonesia', 'Perempuan', 'Jatmiko'),
(6, '003', '331013001100003', 'Udang', 'Sirembes', '09', '33', 'Penungkula', 'Minggu', 'Purwore', 'Minggu', '54081', 'Surakarta', '10/01/2000', 'Kristen', 'Belum Kawin', 'Kepala Kelua', 'Petani', 'TAMAT SD / SEDERAJAT', 'A', 'Indonesia', 'Laki-Laki', 'Pulung'),
(7, '004', '331013001100004', 'Ebi', 'Sirembes', '69', '3', 'Penungkula', 'Selasa', 'Purwore', 'Selasa', '54123', 'Bandung', '10/01/2000', 'Budha', 'Belum Kawin', 'Kepala Kelua', 'Buruh', 'TAMAT SD / SEDERAJAT', 'A', 'Indonesia', 'Laki-Laki', 'Paimin'),
(8, '005', '331013001100005', 'Sulis', 'sirembes', '1', '1', 'Penungkula', 'Jumat', 'Purwore', 'Jumat', '54971', 'Klaten', '', 'islam', 'Belum kawin', 'Kepala Kelua', 'Mahasiswa', 'SMP', 'A', 'Indonesia', 'Perempuan', 'Tomo'),
(12, '454545', '45457575454223', 'muchklisaaaaaaaa', 'SRB', '1', '1', 'PENUNGKULA', 'GEBANG', 'PURWORE', 'JAWA TENGAH', '54191', 'purworejo', '2022-03-10', 'islam', 'Belum kawin', 'Kepala Kelua', 'Mhs', 'SD', 'A', 'Warga Negara Indones', 'Laki-Laki', 'slamet');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_perdukuhan`
--

CREATE TABLE `tbl_perdukuhan` (
  `kd_perdukuhan` varchar(3) NOT NULL,
  `nama_perdukuhan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_perdukuhan`
--

INSERT INTO `tbl_perdukuhan` (`kd_perdukuhan`, `nama_perdukuhan`) VALUES
('SRB', 'Sirembes'),
('SWN', 'Swinong a');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pindah_keluar`
--

CREATE TABLE `tbl_pindah_keluar` (
  `no_pindah_keluar` int(100) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `tgl_pindah` varchar(10) NOT NULL,
  `alasan` text NOT NULL,
  `almat_tujuan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_pindah_keluar`
--

INSERT INTO `tbl_pindah_keluar` (`no_pindah_keluar`, `nik`, `tgl_pindah`, `alasan`, `almat_tujuan`) VALUES
(2, '23213213123213', '2022-02-02', 'pindah kerja', 'kaliboto'),
(123, '23131231231223', '12032012', 'lelah', 'sirembes p');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `username` varchar(15) NOT NULL,
  `nik` varchar(21) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`username`, `nik`, `password`, `level`) VALUES
('admin', '12345', 'admin123', 'A'),
('andi', '12345678912', 'andi123', 'A'),
('asw', '121331313', 'asw123', 'A'),
('yogi', '333333333333', 'yogi123', 'Masyarakat');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_anggota_kk`
--
ALTER TABLE `tbl_anggota_kk`
  ADD PRIMARY KEY (`nomer`);

--
-- Indeks untuk tabel `tbl_kelahiran`
--
ALTER TABLE `tbl_kelahiran`
  ADD PRIMARY KEY (`no_kelahiran`);

--
-- Indeks untuk tabel `tbl_kematian`
--
ALTER TABLE `tbl_kematian`
  ADD PRIMARY KEY (`no_kematian`);

--
-- Indeks untuk tabel `tbl_kk`
--
ALTER TABLE `tbl_kk`
  ADD PRIMARY KEY (`no_kk`);

--
-- Indeks untuk tabel `tbl_pekerjaan`
--
ALTER TABLE `tbl_pekerjaan`
  ADD PRIMARY KEY (`kd_pekerjaan`);

--
-- Indeks untuk tabel `tbl_pendatang`
--
ALTER TABLE `tbl_pendatang`
  ADD PRIMARY KEY (`no_pendatang`);

--
-- Indeks untuk tabel `tbl_pendidikan`
--
ALTER TABLE `tbl_pendidikan`
  ADD PRIMARY KEY (`kd_pendidikan`);

--
-- Indeks untuk tabel `tbl_penduduk`
--
ALTER TABLE `tbl_penduduk`
  ADD PRIMARY KEY (`id_penduduk`);

--
-- Indeks untuk tabel `tbl_perdukuhan`
--
ALTER TABLE `tbl_perdukuhan`
  ADD PRIMARY KEY (`kd_perdukuhan`);

--
-- Indeks untuk tabel `tbl_pindah_keluar`
--
ALTER TABLE `tbl_pindah_keluar`
  ADD PRIMARY KEY (`no_pindah_keluar`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_kelahiran`
--
ALTER TABLE `tbl_kelahiran`
  MODIFY `no_kelahiran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `tbl_kematian`
--
ALTER TABLE `tbl_kematian`
  MODIFY `no_kematian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tbl_pendatang`
--
ALTER TABLE `tbl_pendatang`
  MODIFY `no_pendatang` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_penduduk`
--
ALTER TABLE `tbl_penduduk`
  MODIFY `id_penduduk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
