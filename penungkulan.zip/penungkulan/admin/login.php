<?php
include "lib/koneksi.php";

$username = $_POST['username'];
$password = $_POST['password'];

$sql_admin = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username = '$username' AND password = '$password'");

$data_admin = mysqli_fetch_array($sql_admin);

$jumlah_admin = mysqli_num_rows($sql_admin);


if ($jumlah_admin == 1) {
	session_start();
	$_SESSION['username'] = $data_admin['username'];
	$_SESSION['level'] = $data_admin['level'];
	$_SESSION['nik'] = $data_admin['nik'];

	header('location:dashboard.php');
} else {
	header('location:index.php?pesan=gagal');
}
