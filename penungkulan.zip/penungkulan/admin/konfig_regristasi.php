<?php

include "lib/koneksi.php";

$username = $_POST['username'];
$password = $_POST['password'];
$nik = $_POST['nik'];
$level = $_POST['level'];

mysqli_query($koneksi, "INSERT INTO tbl_user (username, password, nik, level) VALUES ('$username', '$password', '$nik', '$level')");

header("location:index.php");
