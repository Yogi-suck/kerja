<?php

include "../../lib/koneksi.php";

$no_kematian = $_POST['no_kematian'];
$nik = $_POST['nik'];
$hari = $_POST['hari'];
$tanggal = $_POST['tanggal'];
$tempat = $_POST['tempat'];
$penyebab = $_POST['penyebab'];
$nik_pelapor = $_POST['nik_pelapor'];
$hub_pelapor = $_POST['hub_pelapor'];

mysqli_query($koneksi, "INSERT INTO tbl_kematian (nik, hari, tanggal, tempat, penyebab, nik_pelapor, hub_pelapor) VALUES ('$nik','$hari','$tanggal', '$tempat', '$penyebab', '$nik_pelapor', '$hub_pelapor')");

mysqli_query($koneksi, "DELETE FROM tbl_penduduk WHERE nik='$nik'");

header("location:main.php");
