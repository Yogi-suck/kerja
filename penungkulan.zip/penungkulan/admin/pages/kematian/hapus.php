<?php
include "../../lib/koneksi.php";

$no_kematian = $_GET['no_kematian'];
mysqli_query($koneksi, "DELETE FROM tbl_kematian WHERE no_kematian='$no_kematian'");

header("location:main.php");
