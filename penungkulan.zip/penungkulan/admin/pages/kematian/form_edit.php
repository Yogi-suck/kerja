<?php
include "../../header.php";
?>
<!-- Main Content -->
<div class="container-fluid">
  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Edit Data Kematian</h4>
            <div class="card-header-action">
              <a href="<?php echo $baseUrl; ?>/pages/kematian/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data Kematian</a>
            </div>
          </div>
          <div class="card-body p-0">

            <?php
            include '../../lib/koneksi.php';
            $no_kematian = $_GET['no_kematian'];
            $data = mysqli_query($koneksi, "select * from tbl_kematian where no_kematian='$no_kematian'");
            while ($q = mysqli_fetch_array($data)) {
            ?>

              <div class="card-body">

                <form action="simpan_edit.php" method="POST">
                  <input type="hidden" name="no_kematian" value="<?php echo $q['no_kematian']; ?>">

                  <div class="form-group">
                    <label>Nomer Kematian</label>
                    <input type="text" class="form-control" name="no_kematian" value="<?= $q['no_kematian']; ?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Nik</label>
                    <input type="text" class="form-control" name="nik" value="<?= $q['nik']; ?>"readonly>
                  </div>
                  <div class="form-group">
                    <label>Hari</label>
                    <input type="text" class="form-control" name="hari" value="<?= $q['hari']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Tanggal</label>
                    <input type="date" class="form-control" name="tanggal" value="<?= $q['tanggal']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Tempat</label>
                    <input type="text" class="form-control" name="tempat" value="<?= $q['tempat']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Penyebab</label>
                    <input type="text" class="form-control" name="penyebab" value="<?= $q['penyebab']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Nik Pelapor</label>
                    <input type="text" class="form-control" name="nik_pelapor" value="<?= $q['nik_pelapor']; ?>"readonly>
                  </div>
                  <div class="form-group">
                    <label>Hub Pelapor</label>
                    <input type="text" class="form-control" name="hub_pelapor" value="<?= $q['hub_pelapor']; ?>"readonly>
                  </div>


                  <div class="card-footer text-right">
                    <button onclick="return confirm('Apakah anda yakin ingin mengganti data ini ?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  </div>
                </form>
              <?php } ?>
              </div>
          </div>
        </div>
      </div>
  </section>
</div>


<?php
include "../../footer.php";
?>