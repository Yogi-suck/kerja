<?php

include "../../lib/koneksi.php";

$no_kematian = $_POST['no_kematian'];
$nik = $_POST['nik'];
$hari = $_POST['hari'];
$tanggal = $_POST['tanggal'];
$tempat = $_POST['tempat'];
$penyebab = $_POST['penyebab'];
$nik_pelapor = $_POST['nik_pelapor'];
$hub_pelapor = $_POST['hub_pelapor'];

mysqli_query($koneksi, "UPDATE tbl_kematian SET nik='$nik', hari='$hari', tanggal='$tanggal', tempat='$tempat', penyebab='$penyebab', nik_pelapor='$nik_pelapor', hub_pelapor='$hub_pelapor' WHERE no_kematian='$no_kematian'");

header("location:main.php");
