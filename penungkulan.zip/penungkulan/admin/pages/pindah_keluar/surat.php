<?php
include '../../lib/koneksi.php';
$no_pindah_keluar = $_GET['no_pindah_keluar'];
$data = mysqli_query($koneksi, "select * from tbl_pindah_keluar where no_pindah_keluar='$no_pindah_keluar'");
while ($q = mysqli_fetch_array($data)) {
?>

    <!DOCTYPE html>

    <head>
        <title>SURAT KETERANGAN PINDAH KELUAR</title>
        <meta charset="utf-8">
        <style>
            #judul {
                text-align: center;
            }

            #halaman {
                width: auto;
                height: auto;
                position: absolute;
                border: 1px solid;
                padding-top: 30px;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 80px;
            }
        </style>

    </head>

    <body>
        <div id=halaman>
            <h3 id=judul>SURAT KETERANGAN PINDAH KELUAR</h3>

            <p>Data pindah keluar :</p>

            <table>
                <tr>
                    <td style="width: 30%;">Nik Kepala Keluarga</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik_kepala_keluarga']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Tanggal Pindah</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['tgl_pindah']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Alasan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['alasan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Alamat Tujuan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['almat_tujuan']; ?></td>
                </tr>
            </table>

            <p>Data tersebut merupakan data pindah keluar.</p>

            <div style="width: 50%; text-align: left; float: right;">Purowrejo, 25 Februari 2022</div><br>
            <div style="width: 50%; text-align: left; float: right;">Yang bertanda tangan,</div><br><br><br><br><br>
            <div style="width: 50%; text-align: left; float: right;">Ahmad Suroso</div>

        </div>
    <?php } ?>
    </body>
    <script>
        window.print();
    </script>

    </html>