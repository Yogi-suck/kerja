<?php

include "../../lib/koneksi.php";

$no_pindah_keluar = $_POST['no_pindah_keluar'];
$nik = $_POST['nik'];
$nik_kepala_keluarga = $_POST['nik_kepala_keluarga'];
$tgl_pindah = $_POST['tgl_pindah'];
$alasan = $_POST['alasan'];
$almat_tujuan = $_POST['almat_tujuan'];

mysqli_query($koneksi, "INSERT INTO tbl_pindah_keluar (nik, nik_kepala_keluarga, tgl_pindah, alasan, almat_tujuan) VALUES ('$nik', '$nik_kepala_keluarga','$tgl_pindah','$alasan', '$almat_tujuan')");

mysqli_query($koneksi, "DELETE FROM tbl_penduduk WHERE nik='$nik'");

header("location:main.php");
