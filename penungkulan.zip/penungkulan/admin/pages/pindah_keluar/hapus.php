<?php
include "../../lib/koneksi.php";

$no_pindah_keluar = $_GET['no_pindah_keluar'];
mysqli_query($koneksi, "DELETE FROM tbl_pindah_keluar WHERE no_pindah_keluar ='$no_pindah_keluar'");

header("location:main.php");
