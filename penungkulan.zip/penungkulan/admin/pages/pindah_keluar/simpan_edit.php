<?php

include "../../lib/koneksi.php";

$no_pindah_keluar = $_POST['no_pindah_keluar'];
$nik = $_POST['nik'];
$nik_kepala_keluarga = $_POST['nik_kepala_keluarga'];
$tgl_pindah = $_POST['tgl_pindah'];
$alasan = $_POST['alasan'];
$almat_tujuan = $_POST['almat_tujuan'];


mysqli_query($koneksi, "UPDATE tbl_pindah_keluar SET nik = '$nik', nik_kepala_keluarga='$nik_kepala_keluarga', tgl_pindah='$tgl_pindah', alasan='$alasan', almat_tujuan='$almat_tujuan' WHERE no_pindah_keluar='$no_pindah_keluar'");

header("location:main.php");
