<?php
include "../../header.php";
?>
<!-- Main Content -->
<div class="container-fluid">
  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Edit Data Pindah Keluar</h4>
            <div class="card-header-action">
              <a href="<?php echo $baseUrl; ?>/pages/pindah_keluar/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data Pindah Keluar</a>
            </div>
          </div>
          <div class="card-body p-0">

            <?php
            include '../../lib/koneksi.php';
            $no_pindah_keluar = $_GET['no_pindah_keluar'];
            $data = mysqli_query($koneksi, "select * from tbl_pindah_keluar where no_pindah_keluar='$no_pindah_keluar'");
            while ($q = mysqli_fetch_array($data)) {
            ?>

              <div class="card-body">
                <div class="section-title mt-0">Text</div>

                <form action="simpan_edit.php" method="POST">
                  <input type="hidden" name="no_pindah_keluar" value="<?php echo $q['no_pindah_keluar']; ?>">

                  <div class="form-group">
                    <label>Nomer Pindah Keluar</label>
                    <input type="text" class="form-control" name="no_pindah_keluar" value="<?= $q['no_pindah_keluar']; ?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Nik</label>
                    <input type="text" class="form-control" name="nik" value="<?= $q['nik']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Nik Kepala Keluarga</label>
                    <input type="text" class="form-control" name="nik_kepala_keluarga" value="<?= $q['nik_kepala_keluarga']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Tanggal Pindah</label>
                    <input type="text" class="form-control" name="tgl_pindah" value="<?= $q['tgl_pindah']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Alasan</label>
                    <input type="text" class="form-control" name="alasan" value="<?= $q['alasan']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Alamat Tujuan</label>
                    <input type="text" class="form-control" name="almat_tujuan" value="<?= $q['almat_tujuan']; ?>">
                  </div>


                  <div class="card-footer text-right">
                    <button onclick="return confirm('Apakah anda yakin ingin mengganti data ini ?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  </div>
                </form>
              <?php } ?>
              </div>
          </div>
        </div>
      </div>
  </section>
</div>


<?php
include "../../footer.php";
?>