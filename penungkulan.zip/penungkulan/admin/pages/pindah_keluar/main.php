<?php
include "../../header.php";
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Data Pindah Keluar</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Pindah Keluar</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div>
                    <a href="<?php echo $baseUrl; ?>/pages/pindah_keluar/form_tambah.php" class="btn btn-danger">Tambah Data Pindah Keluar <i class="fas fa-chevron-right"></i></a>
                    <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-info"><i class="fas fa-upload"></i> Impor Data Pindah Keluar</button>

                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Impor Data Pindah Keluar</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form method="POST" enctype="multipart/form-data" action="upload_excel.php">
                                    <div class="modal-body">

                                        <div class="form-group">
                                            <label for="import">Data Excel</label>
                                            <input type="file" class="form-control-file" name="import" id="import">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                        <button type="submit" class="btn btn-primary">Impor</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nomer Pindah Keluar</th>
                            <th>Nik</th>
                            <th>Tanggal Pindah</th>
                            <th>Alasan</th>
                            <th>Alamat Tujuan</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        if ($_SESSION['level'] == 'A') {
                            $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pindah_keluar");
                        } else {
                            $nik = $_SESSION['nik'];
                            $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pindah_keluar WHERE nik = '$nik'");
                        }
                        while ($data = mysqli_fetch_array($sql)) {
                        ?>
                            <tr>
                                <td><?php echo $data['no_pindah_keluar'] ?></a></td>
                                <td><?php echo $data['nik'] ?></a></td>
                                <td><?php echo $data['tgl_pindah'] ?></a></td>
                                <td><?php echo $data['alasan'] ?></td>
                                <td><?php echo $data['almat_tujuan'] ?></td>
                                <td class="text-nowrap">
                                    <a href="<?= $baseUrl; ?>../pages/pindah_keluar/form_edit.php?no_pindah_keluar=<?= $data['no_pindah_keluar']; ?>" class="btn btn-primary">Memperbaharui</a>
                                    <a href="<?= $baseUrl; ?>../pages/pindah_keluar/hapus.php?no_pindah_keluar=<?= $data['no_pindah_keluar']; ?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini ?')" class="btn btn-danger">Hapus</a>
                                    <a href="<?= $baseUrl; ?>../pages/pindah_keluar/surat.php?no_pindah_keluar=<?= $data['no_pindah_keluar']; ?>" class="btn btn-primary">Cetak Surat</a>
                                </td>
                            </tr>

                        <?php } ?>

                    </tbody>
                </table>
            </div>
            <a href="<?php echo $baseUrl; ?>/pages/pindah_keluar/cetak.php" class="btn btn-primary mt-3" target="_BLANK"><i class="fas fa-print"></i> CETAK DATA</a>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
include "../../footer.php";
?>