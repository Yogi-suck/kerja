<html>

<head>
  <title>DATA PINDAH KELUAR PENUNGKULAN</title>
</head>

<body>

  <?php session_start();

  include "../../lib/koneksi.php";
  ?>

  <div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header">
              <h4>Data Pindah Keluar</h4>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive table-invoice">
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pindah_keluar");
                ?>
                <table class="table table-striped">
                  <tr>
                    <th>Nomer Pindah Keluar</th>
                    <th>Nik Kepala Keluarga</th>
                    <th>Tanggal Pindah</th>
                    <th>Alasan</th>
                    <th>Alamat Tujuan</th>
                  </tr>
                  <?php
                  while ($data = mysqli_fetch_array($sql)) {
                  ?>
                    <tr>
                      <td><?php echo $data['no_pindah_keluar'] ?></a></td>
                      <td><?php echo $data['nik_kepala_keluarga'] ?></a></td>
                      <td><?php echo $data['tgl_pindah'] ?></a></td>
                      <td><?php echo $data['alasan'] ?></td>
                      <td><?php echo $data['almat_tujuan'] ?></td>
                    </tr>

                  <?php } ?>

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script>
    window.print();
  </script>

</body>

</html>