<?php
include "../../header.php";
?>
<!-- Main Content -->
<div class="container-fluid">
  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Tambah Data Pindah Keluar</h4>
            <div class="card-header-action">
              <a href="<?php echo $baseUrl; ?>/pages/pindah_keluar/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data Pindah Keluar</a>
            </div>
          </div>
          <div class="card-body p-0">

            <div class="card-body">

              <form action="simpan_tambah.php" method="POST">

                <div class="form-group">
                  <label>Nik</label>
                  <?php $sql = mysqli_query($koneksi, "SELECT * FROM tbl_penduduk"); ?>
                  <select class="form-control form-control-user" id="nik" name="nik" placeholder="Nomer KK">
                    <?php while ($data = mysqli_fetch_array($sql)) { ?>
                      <option value='<?= $data['nik'] ?>'><?= $data['nik'] ?> - <?= $data['nama_penduduk'] ?></option>
                    <?php } ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Tanggal Pindah</label>
                  <input type="date" class="form-control" name="tgl_pindah">
                </div>
                <div class="form-group">
                  <label>Alasan</label>
                  <input type="text" class="form-control" name="alasan">
                </div>
                <div class="form-group">
                  <label>Alamat Tujuan</label>
                  <input type="text" class="form-control" name="almat_tujuan">
                </div>

                <div class="card-footer text-right">
                  <button onclick="return confirm('Apakah anda yakin ingin menambahkan data ini?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  <button onclick="return confirm('Apakah anda yakin ingin mereset data yang sudah di isi?')" class="btn btn-secondary" type="reset">mengatur ulang</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
  </section>
</div>


<?php
include "../../footer.php";
?>