<?php

include "../../lib/koneksi.php";

$nama = $_POST['nama'];
$nik = $_POST['nik'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$hari = $_POST['hari'];
$tanggal = $_POST['tanggal'];
$jam = $_POST['jam'];
$tempat = $_POST['tempat'];
$nik_ayah = $_POST['nik_ayah'];
$nik_pelapor = $_POST['nik_pelapor'];
$hub_pelapor = $_POST['hub_pelapor'];


$data_ayah = mysqli_query($koneksi, "select * from tbl_penduduk where nik='$nik_ayah'"); 
$ayah = mysqli_fetch_array($data_ayah);

$kk_ayah = $ayah['kk'];
$kd_perdukuhan_ayah = $ayah['kd_perdukuhan'];
$rt_ayah = $ayah['rt'];
$rw_ayah = $ayah['rw'];
$desa_ayah = $ayah['desa'];
$kecamatan_ayah = $ayah['kecamatan'];
$kabupaten_ayah = $ayah['kabupaten'];
$provinsi_ayah = $ayah['provinsi'];
$kodepos_ayah = $ayah['kodepos'];
$tmptlahir_ayah = $ayah['tmptlahir'];
$agama_ayah = $ayah['agama'];
$status_kewarganegaraan_ayah = $ayah['status_kewarganegaraan'];
$nama_ayah = $ayah['nama_ayah'];

$kelahiran = mysqli_query($koneksi, "INSERT INTO tbl_kelahiran (nama, nik, jenis_kelamin, hari, tanggal, jam, tempat,  nik_ayah, nik_pelapor, hub_pelapor) VALUES ('$nama', '$nik', '$jenis_kelamin','$hari', '$tanggal', '$jam', '$tempat', '$nik_ayah', '$nik_pelapor', '$hub_pelapor')");

$penduduk = mysqli_query($koneksi, "INSERT INTO tbl_penduduk (kk, nik, nama_penduduk, kd_perdukuhan, rt, rw, desa, kecamatan, kabupaten, provinsi, kodepos, tmptlahir, tgllahir, agama, statusperkawinan, statushubkeluarga, kd_pekerjaan, kd_pendidikan, gol_darah, status_kewarganegaraan, jenis_kelamin, nama_ayah) VALUES (
	'$kk_ayah', 
	'$nik', 
	'$nama', 
	'$kd_perdukuhan_ayah', 
	'$rt_ayah', 
	'$rw_ayah', 
	'$desa_ayah', 
	'$kecamatan_ayah', 
	'$kabupaten_ayah', 
	'$provinsi_ayah', 
	'$kodepos_ayah', 
	'$tmptlahir_ayah', 
	'$tanggal', 
	'$agama_ayah', 
	'Belum kawin', 
	'Anak Kandung', 
	'Belum Bekerja', 
	'Belum Sekolah', 
	NULL, 
	'$status_kewarganegaraan_ayah', 
	'$jenis_kelamin', 
	'$nama_ayah'
)");


header("location:main.php");