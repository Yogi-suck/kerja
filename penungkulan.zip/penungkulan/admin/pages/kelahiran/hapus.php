<?php
include "../../lib/koneksi.php";

$no_kelahiran = $_GET['no_kelahiran'];
mysqli_query($koneksi, "DELETE FROM tbl_kelahiran WHERE no_kelahiran='$no_kelahiran'");

header("location:main.php");
