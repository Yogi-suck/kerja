<?php

include "../../lib/koneksi.php";

$no_kelahiran = $_POST['no_kelahiran'];
$nama = $_POST['nama'];
$nik = $_POST['nik'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$hari = $_POST['hari'];
$tanggal = $_POST['tanggal'];
$jam = $_POST['jam'];
$tempat = $_POST['tempat'];
$nik_ibu = $_POST['nik_ibu'];
$nik_ayah = $_POST['nik_ayah'];
$nik_pelapor = $_POST['nik_pelapor'];
$hub_pelapor = $_POST['hub_pelapor'];


mysqli_query($koneksi, " UPDATE tbl_kelahiran SET nama ='$nama', nik='$nik', jenis_kelamin ='$jenis_kelamin', hari ='$hari', tanggal ='$tanggal', jam ='$jam', tempat ='$tempat', nik_ibu ='$nik_ibu', nik_ayah ='$nik_ayah', nik_pelapor ='$nik_pelapor', hub_pelapor ='$hub_pelapor' WHERE no_kelahiran='$no_kelahiran' ");

header("location:main.php");
