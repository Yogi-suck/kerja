<html>

<head>
  <title>DATA KELAHIRAN PENUNGKULAN</title>
</head>

<body>

  <?php session_start();

  include "../../lib/koneksi.php";
  ?>

  <div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header">
              <h4>Data Kelahiran</h4>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive table-invoice">
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM tbl_kelahiran");


                ?>
                <table class="table table-striped">
                  <tr>
                    <th>Nomer Kelahiran</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Hari</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Tempat</th>
                    <th>Nik Ibu</th>
                    <th>nik Ayah</th>
                    <th>Nik Pelapor</th>
                    <th>Hub Pelapor</th>
                  </tr>
                  <?php
                  while ($data = mysqli_fetch_array($sql)) {
                  ?>
                    <tr>
                      <td><?php echo $data['no_kelahiran'] ?></a></td>
                      <td><?php echo $data['nama'] ?></a></td>
                      <td><?php echo $data['jenis_kelamin'] ?></a></td>
                      <td><?php echo $data['hari'] ?></td>
                      <td><?php echo $data['tanggal'] ?></td>
                      <td><?php echo $data['jam'] ?></td>
                      <td><?php echo $data['tempat'] ?></td>
                      <td><?php echo $data['nik_ibu'] ?></td>
                      <td><?php echo $data['nik_ayah'] ?></td>
                      <td><?php echo $data['nik_pelapor'] ?></td>
                      <td><?php echo $data['hub_pelapor'] ?></td>
                    </tr>

                  <?php } ?>

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script>
    window.print();
  </script>

</body>

</html>