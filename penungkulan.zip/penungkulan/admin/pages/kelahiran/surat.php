<?php
include '../../lib/koneksi.php';
$no_kelahiran = $_GET['no_kelahiran'];
$data = mysqli_query($koneksi, "select * from tbl_kelahiran where no_kelahiran='$no_kelahiran'");
while ($q = mysqli_fetch_array($data)) {
?>

    <!DOCTYPE html>

    <head>
        <title>SURAT KETERANGAN KELAHIRAN</title>
        <meta charset="utf-8">
        <style>
            #judul {
                text-align: center;
            }

            #halaman {
                width: auto;
                height: auto;
                position: absolute;
                border: 1px solid;
                padding-top: 30px;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 80px;
            }
        </style>

    </head>

    <body>
        <div id=halaman>
            <h3 id=judul>SURAT KETERANGAN KELAHIRAN</h3>

            <p>Data Kelahiran :</p>

            <table>
                <tr>
                    <td style="width: 30%;">Nama</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nama']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Jenis Kelamin</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['jenis_kelamin']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%; vertical-align: top;">Hari</td>
                    <td style="width: 5%; vertical-align: top;">:</td>
                    <td style="width: 65%;"><?= $q['hari']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Tanggal</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['tanggal']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Jam</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['jam']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Tempat</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['tempat']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nik Ibu</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik_ibu']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nik Ayah</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik_ayah']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nik Pelapor</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik_pelapor']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Hub Pelapor</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['hub_pelapor']; ?></td>
                </tr>
            </table>

            <p>Data tersebut merupakan data kelahiran.</p>

            <div style="width: 50%; text-align: left; float: right;">Purowrejo, 25 Februari 2022</div><br>
            <div style="width: 50%; text-align: left; float: right;">Yang bertanda tangan,</div><br><br><br><br><br>
            <div style="width: 50%; text-align: left; float: right;">Ahmad Suroso</div>

        </div>
    <?php } ?>
    </body>
    <script>
        window.print();
    </script>

    </html>