<?php
include "../../header.php";
?>
<!-- Main Content -->
<div class="container-fluid">
  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Edit Data Kelahiran</h4>
            <div class="card-header-action">
              <a href="<?php echo $baseUrl; ?>/pages/kelahiran/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data Kelahiran</a>
            </div>
          </div>
          <div class="card-body p-0">

            <?php
            include '../../lib/koneksi.php';
            $no_kelahiran = $_GET['no_kelahiran'];
            $data = mysqli_query($koneksi, "select * from tbl_kelahiran where no_kelahiran='$no_kelahiran'");
            while ($q = mysqli_fetch_array($data)) {
            ?>

              <div class="card-body">
                <div class="section-title mt-0">Text</div>

                <form action="simpan_edit.php" method="POST">
                  <input type="hidden" name="no_kelahiran" value="<?php echo $q['no_kelahiran']; ?>">

                  <div class="form-group">
                    <label>Nomer Kelahiran</label>
                    <input type="text" class="form-control" name="no_kelahiran" value="<?= $q['no_kelahiran']; ?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Nama</label>
                    <input type="text" class="form-control" name="nama" value="<?= $q['nama']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Nik</label>
                    <input type="text" class="form-control" name="nik" value="<?= $q['nik']; ?>"readonly>
                  </div>
                  <div class="form-group">
                    <label>nik Ayah</label>
                    <input type="text" class="form-control" name="nik_ayah" value="<?= $q['nik_ayah']; ?>"readonly>
                  </div>
                  <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select class="form-control form-control-user" name='jenis_kelamin'>
                      <option <?php echo ($q['jenis_kelamin'] == 'Laki-Laki') ? "selected" : "" ?> value='Laki-Laki'>Laki-Laki</option>
                      <option <?php echo ($q['jenis_kelamin'] == 'Perempuan') ? "selected" : "" ?> value='Perempuan'>Perempuan</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Hari</label>
                    <input type="text" class="form-control" name="hari" value="<?= $q['hari']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Tanggal</label>
                    <input type="date" class="form-control" name="tanggal" value="<?= date('Y-m-d', strtotime($q['tanggal'])); ?>">
                  </div>
                  <div class="form-group">
                    <label>Jam</label>
                    <input type="text" class="form-control" name="jam" value="<?= $q['jam']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Tempat</label>
                    <input type="text" class="form-control" name="tempat" value="<?= $q['tempat']; ?>">
                  </div>
                  
                  <div class="form-group">
                    <label>Nik Pelapor</label>
                    <input type="text" class="form-control" name="nik_pelapor" value="<?= $q['nik_pelapor']; ?>"readonly>
                  </div>
                  <div class="form-group">
                    <label>Hub Pelapor</label>
                    <input type="text" class="form-control" name="hub_pelapor" value="<?= $q['hub_pelapor']; ?>"readonly>
                  </div>


                  <div class="card-footer text-right">
                    <button onclick="return confirm('Apakah anda yakin ingin mengganti data ini ?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  </div>
                </form>
              <?php } ?>
              </div>
          </div>
        </div>
      </div>
  </section>
</div>


<?php
include "../../footer.php";
?>