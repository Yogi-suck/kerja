<?php

include "../../lib/koneksi.php";

$kd_perdukuhan = $_POST['kd_perdukuhan'];
$nama_perdukuhan = $_POST['nama_perdukuhan'];

mysqli_query($koneksi, "UPDATE tbl_perdukuhan SET nama_perdukuhan='$nama_perdukuhan' WHERE kd_perdukuhan='$kd_perdukuhan'");

header("location:main.php");
