<?php
include "../../lib/koneksi.php";

$kd_perdukuhan = $_GET['kd_perdukuhan'];
mysqli_query($koneksi, "DELETE FROM tbl_perdukuhan WHERE kd_perdukuhan='$kd_perdukuhan'");

header("location:main.php");
