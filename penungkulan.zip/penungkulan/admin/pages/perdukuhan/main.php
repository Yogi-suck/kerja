<?php
include "../../header.php";
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Data Perdukuhan</h1>

    <?php
    $sql = mysqli_query($koneksi, "SELECT * FROM tbl_perdukuhan");

    ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Perdukuhan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div>
                    <a href="<?php echo $baseUrl; ?>/pages/perdukuhan/form_tambah.php" class="btn btn-danger">Tambah Data Perdukuhan <i class="fas fa-chevron-right"></i></a>
                </div>
                <hr>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Kode Perdukuhan</th>
                            <th>nama perdukuhan</th>
                            <th>Action</th>
                        </tr>
                    </thead>


                    <tbody>
                        <?php
                        while ($data = mysqli_fetch_array($sql)) {
                        ?>
                            <tr>
                                <td><?php echo $data['kd_perdukuhan'] ?></a></td>
                                <td><?php echo $data['nama_perdukuhan'] ?></a></td>
                                <td class="text-nowrap">
                                    <a href="<?= $baseUrl; ?>../pages/perdukuhan/form_edit.php?kd_perdukuhan=<?= $data['kd_perdukuhan']; ?>" class="btn btn-primary">Memperbaharui</a>
                                    <a href="<?= $baseUrl; ?>../pages/perdukuhan/hapus.php?kd_perdukuhan=<?= $data['kd_perdukuhan']; ?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini ?')" class="btn btn-danger">Hapus</a>
                                    <a href="<?= $baseUrl; ?>../pages/perdukuhan/surat.php?kd_perdukuhan=<?= $data['kd_perdukuhan']; ?>" class="btn btn-primary">Cetak Surat</a>
                                </td>
                            </tr>

                        <?php } ?>

                    </tbody>
                </table>
            </div>
            <a href="<?php echo $baseUrl; ?>/pages/perdukuhan/cetak.php" class="btn btn-primary mt-3" target="_BLANK"><i class="fas fa-print"></i> CETAK DATA</a>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
include "../../footer.php";
?>