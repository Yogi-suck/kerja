<?php

include "../../lib/koneksi.php";

$kd_perdukuhan = $_POST['kd_perdukuhan'];
$nama_perdukuhan = $_POST['nama_perdukuhan'];

mysqli_query($koneksi, "INSERT INTO tbl_perdukuhan (kd_perdukuhan, nama_perdukuhan) VALUES ('$kd_perdukuhan', '$nama_perdukuhan')");

header("location:main.php");
