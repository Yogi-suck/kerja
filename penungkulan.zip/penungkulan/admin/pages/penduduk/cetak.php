<html>

<head>
  <title>DATA PENDUDUK PENUNGKULAN</title>
</head>

<body>

  <?php session_start();

  include "../../lib/koneksi.php";
  ?>

  <div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header">
              <h4>Data Penduduk</h4>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive table-invoice">
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM tbl_penduduk");
                ?>
                <table class="table table-striped">
                  <tr>
                    <th>Nomer Induk Kependudukan</th>
                    <th>Nama Penduduk</th>
                    <th>Perdukuhan</th>
                    <th>RT</th>
                    <th>Rw</th>
                    <th>Desa</th>
                    <th>Kecamatan</th>
                    <th>Kabupaten</th>
                    <th>Provinsi</th>
                    <th>Kode Pos</th>
                    <th>Tempat Lahir</th>
                    <th>Tanggal Lahir</th>
                    <th>Agama</th>
                    <th>Setatus Perkawinan</th>
                    <th>Hubungan Keluarga</th>
                    <th>Pekerjaan</th>
                    <th>Pendidikan</th>
                    <th>Golongan Darah</th>
                    <th>Setatus kwarganegaraan</th>
                    <th>Jenis Kelamin</th>
                    <th>Nama Ayah</th>
                  </tr>
                  <?php
                  while ($data = mysqli_fetch_array($sql)) {
                  ?>
                    <tr>
                      <td><?php echo $data['nik'] ?></a></td>
                      <td><?php echo $data['nama_penduduk'] ?></a></td>
                      <td><?php echo $data['kd_perdukuhan'] ?></a></td>
                      <td><?php echo $data['rt'] ?></td>
                      <td><?php echo $data['rw'] ?></td>
                      <td><?php echo $data['desa'] ?></td>
                      <td><?php echo $data['kecamatan'] ?></td>
                      <td><?php echo $data['kabupaten'] ?></td>
                      <td><?php echo $data['provinsi'] ?></td>
                      <td><?php echo $data['kodepos'] ?></td>
                      <td><?php echo $data['tmptlahir'] ?></td>
                      <td><?php echo $data['tgllahir'] ?>
              </div>
              </td>
              <td><?php echo $data['agama'] ?>
            </div>
            </td>
            <td><?php echo $data['statusperkawinan'] ?></td>
            <td><?php echo $data['statushubkeluarga'] ?></td>
            <td><?php echo $data['kd_pekerjaan'] ?></td>
            <td><?php echo $data['kd_pendidikan'] ?></td>
            <td><?php echo $data['gol_darah'] ?></td>
            <td><?php echo $data['status_kewarganegaraan'] ?></td>
            <td><?php echo $data['jenis_kelamin'] ?></td>
            <td><?php echo $data['nama_ayah'] ?></td>
            </tr>

          <?php } ?>

          </table>
          </div>
        </div>
      </div>
  </div>
  </div>
  </section>
  </div>

  <script>
    window.print();
  </script>

</body>

</html>