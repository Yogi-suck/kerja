<?php
include "../../lib/koneksi.php";

$nik = $_GET['nik'];
mysqli_query($koneksi, "DELETE FROM tbl_penduduk WHERE nik='$nik'");

mysqli_query($koneksi, "DELETE FROM tbl_pendatang_baru WHERE nik='$nik'");

header("location:main.php");
