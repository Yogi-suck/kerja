<?php

include "../../lib/koneksi.php";

$id_penduduk = $_POST['id_penduduk'];
$kk = $_POST['kk'];
$nik = $_POST['nik'];
$nama_penduduk = $_POST['nama_penduduk'];
$kd_perdukuhan = $_POST['kd_perdukuhan'];
$rt = $_POST['rt'];
$rw = $_POST['rw'];
$desa = $_POST['desa'];
$kecamatan = $_POST['kecamatan'];
$kabupaten = $_POST['kabupaten'];
$provinsi = $_POST['provinsi'];
$kodepos = $_POST['kodepos'];
$tmptlahir = $_POST['tmptlahir'];
$tgllahir = $_POST['tgllahir'];
$agama = $_POST['agama'];
$statusperkawinan = $_POST['statusperkawinan'];
$statushubkeluarga = $_POST['statushubkeluarga'];
$kd_pekerjaan = $_POST['kd_pekerjaan'];
$kd_pendidikan = $_POST['kd_pendidikan'];
$gol_darah = $_POST['gol_darah'];
$status_kewarganegaraan = $_POST['status_kewarganegaraan'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$nama_ayah = $_POST['nama_ayah'];


mysqli_query($koneksi, "UPDATE tbl_penduduk SET kk = '$kk', nik='$nik', nama_penduduk='$nama_penduduk', kd_perdukuhan='$kd_perdukuhan', rt='$rt', rw='$rw', desa='$desa', kecamatan='$kecamatan', kabupaten='$kabupaten', provinsi='$provinsi', kodepos='$kodepos', tmptlahir='$tmptlahir', tgllahir='$tgllahir', agama='$agama', statusperkawinan='$statusperkawinan', statushubkeluarga='$statushubkeluarga', kd_pekerjaan='$kd_pekerjaan', kd_pendidikan='$kd_pendidikan', gol_darah='$gol_darah', status_kewarganegaraan='$status_kewarganegaraan', jenis_kelamin='$jenis_kelamin', nama_ayah='$nama_ayah' WHERE id_penduduk='$id_penduduk'");

header("location:main.php");
