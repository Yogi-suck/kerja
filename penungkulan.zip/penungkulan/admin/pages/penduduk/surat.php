<?php
include '../../lib/koneksi.php';
$nik = $_GET['nik'];
$data = mysqli_query($koneksi, "select * from tbl_penduduk where nik='$nik'");
while ($q = mysqli_fetch_array($data)) {
?>

    <!DOCTYPE html>

    <head>
        <title>SURAT KETERANGAN PENDUDUK</title>
        <meta charset="utf-8">
        <style>
            #judul {
                text-align: center;
            }

            #halaman {
                width: auto;
                height: auto;
                position: absolute;
                border: 1px solid;
                padding-top: 30px;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 80px;
            }
        </style>

    </head>

    <body>
        <div id=halaman>
            <h3 id=judul>SURAT KETERANGAN PENDUDUK</h3>

            <p>Data penduduk :</p>

            <table>
                <tr>
                    <td style="width: 30%;">Nomer KK</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kk']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nomer Induk Kependudukan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nama Penduduk</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nama_penduduk']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Perdukuhan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kd_perdukuhan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">RT</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['rt']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Rw</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['rw']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Desa</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['desa']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Kecamatan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kecamatan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Kabupaten</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kabupaten']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Provinsi</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['provinsi']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Kode Pos</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kodepos']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Tempat Lahir</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['tmptlahir']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Tanggal Lahir</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['tgllahir']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Agama</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['agama']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Setatus Perkawinan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['statusperkawinan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Hubungan Keluarga</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['statushubkeluarga']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Pekerjaan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kd_pekerjaan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Pendidikan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kd_pendidikan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Golongan Darah</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['gol_darah']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Setatus kwarganegaraan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['status_kewarganegaraan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Jenis Kelamin</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['jenis_kelamin']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nama Ayah</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nama_ayah']; ?></td>
                </tr>
            </table>

            <p>Data tersebut merupakan data penduduk.</p>

            <div style="width: 50%; text-align: left; float: right;">Purowrejo, 25 Februari 2022</div><br>
            <div style="width: 50%; text-align: left; float: right;">Yang bertanda tangan,</div><br><br><br><br><br>
            <div style="width: 50%; text-align: left; float: right;">Ahmad Suroso</div>

        </div>
    <?php } ?>
    </body>
    <script>
        window.print();
    </script>

    </html>