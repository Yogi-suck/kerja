<?php

include "../../lib/koneksi.php";

$kk = $_POST['kk'];
$nik = $_POST['nik'];
$nama_penduduk = $_POST['nama_penduduk'];
$kd_perdukuhan = $_POST['kd_perdukuhan'];
$rt = $_POST['rt'];
$rw = $_POST['rw'];
$desa = $_POST['desa'];
$kecamatan = $_POST['kecamatan'];
$kabupaten = $_POST['kabupaten'];
$provinsi = $_POST['provinsi'];
$kodepos = $_POST['kodepos'];
$tmptlahir = $_POST['tmptlahir'];
$tgllahir = $_POST['tgllahir'];
$agama = $_POST['agama'];
$statusperkawinan = $_POST['statusperkawinan'];
$statushubkeluarga = $_POST['statushubkeluarga'];
$kd_pekerjaan = $_POST['kd_pekerjaan'];
$kd_pendidikan = $_POST['kd_pendidikan'];
$gol_darah = $_POST['gol_darah'];
$status_kewarganegaraan = $_POST['status_kewarganegaraan'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$nama_ayah = $_POST['nama_ayah'];

mysqli_query($koneksi, "INSERT INTO tbl_penduduk (kk, nik, nama_penduduk, kd_perdukuhan, rt, rw, desa, kecamatan, kabupaten, provinsi, kodepos, tmptlahir, tgllahir, agama, statusperkawinan, statushubkeluarga, kd_pekerjaan, kd_pendidikan, gol_darah, status_kewarganegaraan, jenis_kelamin, nama_ayah) VALUES ('$kk', '$nik', '$nama_penduduk', '$kd_perdukuhan', '$rt', '$rw', '$desa', '$kecamatan', '$kabupaten', '$provinsi', '$kodepos', '$tmptlahir', '$tgllahir', '$agama', '$statusperkawinan', '$statushubkeluarga', '$kd_pekerjaan', '$kd_pendidikan', '$gol_darah', '$status_kewarganegaraan', '$jenis_kelamin', '$nama_ayah')");

header("location:main.php");
