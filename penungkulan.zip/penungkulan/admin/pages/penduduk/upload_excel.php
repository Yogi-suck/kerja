<?php
// menghubungkan dengan koneksi
include '../../lib/koneksi.php';
// menghubungkan dengan library excel reader
include "../../lib/excel_reader2.php";

// upload file xls
$target = basename($_FILES['import']['name']);
move_uploaded_file($_FILES['import']['tmp_name'], $target);

// beri permisi agar file xls dapat di baca
chmod($_FILES['import']['name'], 0777);

// mengambil isi file xls
$data = new Spreadsheet_Excel_Reader($_FILES['import']['name'], false);
// menghitung jumlah baris data yang ada
$jumlah_baris = $data->rowcount($sheet_index = 0);

// jumlah default data yang berhasil di import
$berhasil = 0;
for ($i = 3; $i <= $jumlah_baris; $i++) {
	// menangkap data dan memasukkan ke variabel sesuai dengan kolumnya masing-masing
	$kk = $data->val($i, 3);
	$nik = $data->val($i, 4);
	$nama = $data->val($i, 5);
	$perdukuhan = $data->val($i, 6);
	$rt = $data->val($i, 7);
	$rw = $data->val($i, 8);
	$desa = $data->val($i, 9);
	$kecamatan = $data->val($i, 10);
	$kabupaten = $data->val($i, 11);
	$provinsi = $data->val($i, 12);
	$kodepos = $data->val($i, 13);
	$tmptlahir = $data->val($i, 14);
	$tgllahir = $data->val($i, 15);
	$agama = $data->val($i, 16);
	$statusperkawinan = $data->val($i, 17);
	$statushubkeluarga = $data->val($i, 18);
	$kd_pekerjaan = $data->val($i, 19);
	$kd_pendidikan = $data->val($i, 20);
	$gol_darah = $data->val($i, 21);
	$status_kewarganegaraan = $data->val($i, 22);
	$jenis_kelamin = $data->val($i, 23);
	$nama_ayah = $data->val($i, 24);

	if ($kk != "" && $nik != "" && $nama != "" && $perdukuhan != "" && $rt != "" && $rw != "" && $desa != "" && $kecamatan != "" && $kabupaten != "" && $provinsi != "" && $kodepos != "" && $tmptlahir != "" && $tgllahir != "" && $agama != "" && $statusperkawinan != "" && $statushubkeluarga != "" && $kd_pekerjaan != "" && $kd_pendidikan != "" && $gol_darah != "" && $status_kewarganegaraan != "" && $jenis_kelamin != "" && $nama_ayah != "") {
		mysqli_query($koneksi, "INSERT INTO tbl_penduduk VALUES ('', '$kk','$nik','$nama', '$perdukuhan', '$rt', '$rw', '$desa', '$kecamatan','$kabupaten','$provinsi', '$kodepos', '$tmptlahir', '$tgllahir', '$agama', '$statusperkawinan','$statushubkeluarga','$kd_pekerjaan', '$kd_pendidikan', '$gol_darah', '$status_kewarganegaraan', '$jenis_kelamin', '$nama_ayah')");
		$berhasil++;
	}
}

// hapus kembali file .xls yang di upload tadi
unlink($_FILES['import']['name']);

// alihkan halaman ke index.php
header("location:main.php");
