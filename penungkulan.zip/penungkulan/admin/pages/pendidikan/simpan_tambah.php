<?php

include "../../lib/koneksi.php";

$kd_pendidikan = $_POST['kd_pendidikan'];
$nama_pendidikan = $_POST['nama_pendidikan'];

mysqli_query($koneksi, "INSERT INTO tbl_pendidikan (kd_pendidikan, nama_pendidikan) VALUES ('$kd_pendidikan', '$nama_pendidikan')");

header("location:main.php");
