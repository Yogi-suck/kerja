<?php

include "../../lib/koneksi.php";

$kd_pendidikan = $_POST['kd_pendidikan'];
$nama_pendidikan = $_POST['nama_pendidikan'];

mysqli_query($koneksi, "UPDATE tbl_pendidikan SET nama_pendidikan='$nama_pendidikan' WHERE kd_pendidikan='$kd_pendidikan'");

header("location:main.php");
