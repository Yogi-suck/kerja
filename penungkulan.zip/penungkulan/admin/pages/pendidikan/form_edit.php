<?php
include "../../header.php";
?>
<!-- Main Content -->
<div class="container-fluid">
  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Edit Data Pendidikan</h4>
            <div class="card-header-action">
              <a href="<?php echo $baseUrl; ?>/pages/pendidikan/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data Pendidikan</a>
            </div>
          </div>
          <div class="card-body p-0">

            <?php
            include '../../lib/koneksi.php';
            $kd_pendidikan = $_GET['kd_pendidikan'];
            $data = mysqli_query($koneksi, "select * from tbl_pendidikan where kd_pendidikan='$kd_pendidikan'");
            while ($q = mysqli_fetch_array($data)) {
            ?>

              <div class="card-body">
                <div class="section-title mt-0">Text</div>

                <form action="simpan_edit.php" method="POST">
                  <input type="hidden" name="kd_pendidikan" value="<?php echo $q['kd_pendidikan']; ?>">

                  <div class="form-group">
                    <label>Kode Pendidikan</label>
                    <input type="text" class="form-control" name="kd_pendidikan" value="<?= $q['kd_pendidikan']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Nama Pendidikan</label>
                    <input type="text" class="form-control" name="nama_pendidikan" value="<?= $q['nama_pendidikan']; ?>">
                  </div>


                  <div class="card-footer text-right">
                    <button onclick="return confirm('Apakah anda yakin ingin mengganti data ini ?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  </div>
                </form>
              <?php } ?>
              </div>
          </div>
        </div>
      </div>
  </section>
</div>


<?php
include "../../footer.php";
?>