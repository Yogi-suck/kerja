<?php
include '../../lib/koneksi.php';
$kd_pendidikan = $_GET['kd_pendidikan'];
$data = mysqli_query($koneksi, "select * from tbl_pendidikan where kd_pendidikan='$kd_pendidikan'");
while ($q = mysqli_fetch_array($data)) {
?>

    <!DOCTYPE html>

    <head>
        <title>SURAT KETERANGAN PENDIDIKAN</title>
        <meta charset="utf-8">
        <style>
            #judul {
                text-align: center;
            }

            #halaman {
                width: auto;
                height: auto;
                position: absolute;
                border: 1px solid;
                padding-top: 30px;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 80px;
            }
        </style>

    </head>

    <body>
        <div id=halaman>
            <h3 id=judul>SURAT KETERANGAN PENDIDIKAN</h3>

            <p>Data pendidikan :</p>

            <table>
                <tr>
                    <td style="width: 30%;">Kode Pendidikan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kd_pendidikan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nama Pendidikan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nama_pendidikan']; ?></td>
                </tr>
            </table>

            <p>Data tersebut merupakan data pendidikan.</p>

            <div style="width: 50%; text-align: left; float: right;">Purowrejo, 25 Februari 2022</div><br>
            <div style="width: 50%; text-align: left; float: right;">Yang bertanda tangan,</div><br><br><br><br><br>
            <div style="width: 50%; text-align: left; float: right;">Ahmad Suroso</div>

        </div>
    <?php } ?>
    </body>
    <script>
        window.print();
    </script>

    </html>