<?php
include "../../lib/koneksi.php";

$kd_pendidikan = $_GET['kd_pendidikan'];
mysqli_query($koneksi, "DELETE FROM tbl_pendidikan WHERE kd_pendidikan='$kd_pendidikan'");

header("location:main.php");
