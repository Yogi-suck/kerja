<?php
include "../../lib/koneksi.php";

$nomer = $_GET['nomer'];
mysqli_query($koneksi, "DELETE FROM tbl_anggota_kk WHERE nomer='$nomer'");

header("location:main.php");
