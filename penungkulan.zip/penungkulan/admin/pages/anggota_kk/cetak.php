<html>

<head>
  <title>DATA ANGGOTA KK PENUNGKULAN</title>
</head>

<body>

  <?php session_start();

  include "../../lib/koneksi.php";
  ?>

  <div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header">
              <h4>Data Anggota KK</h4>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive table-invoice">
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM tbl_anggota_kk");


                ?>
                <table class="table table-striped">
                  <tr>
                    <th>Nomer Anggota KK</th>
                    <th>Nomer Kartu Keluarga</th>
                    <th>NIK</th>
                    <th>Status</th>
                  </tr>
                  <?php
                  while ($data = mysqli_fetch_array($sql)) {
                  ?>
                    <tr>
                      <td><?php echo $data['nomer'] ?></a></td>
                      <td><?php echo $data['no_kk'] ?></a></td>
                      <td><?php echo $data['nik'] ?></a></td>
                      <td><?php echo $data['status'] ?></td>
                    </tr>

                  <?php } ?>

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script>
    window.print();
  </script>

</body>

</html>