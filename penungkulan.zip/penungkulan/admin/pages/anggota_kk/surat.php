<?php
include '../../lib/koneksi.php';
$nomer = $_GET['nomer'];
$data = mysqli_query($koneksi, "select * from tbl_anggota_kk where nomer='$nomer'");
while ($q = mysqli_fetch_array($data)) {
?>

    <!DOCTYPE html>

    <head>
        <title>SURAT KETERANGAN ANGGOTA KARTU KELUARGA</title>
        <meta charset="utf-8">
        <style>
            #judul {
                text-align: center;
            }

            #halaman {
                width: auto;
                height: auto;
                position: absolute;
                border: 1px solid;
                padding-top: 30px;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 80px;
            }
        </style>

    </head>

    <body>
        <div id=halaman>
            <h3 id=judul>SURAT KETERANGAN ANGGOTA KARTU KELUARGA</h3>

            <p>Data Anggota Kartu Keluarga :</p>

            <table>
                <tr>
                    <td style="width: 30%;">Nomer Anggota KK</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nomer']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nomer Kartu Keluarga</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['no_kk']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%; vertical-align: top;">NIK</td>
                    <td style="width: 5%; vertical-align: top;">:</td>
                    <td style="width: 65%;"><?= $q['nik']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Status</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['status']; ?></td>
                </tr>
            </table>

            <p>Data tersebut merupakan data anggota kk.</p>

            <div style="width: 50%; text-align: left; float: right;">Purowrejo, 25 Februari 2022</div><br>
            <div style="width: 50%; text-align: left; float: right;">Yang bertanda tangan,</div><br><br><br><br><br>
            <div style="width: 50%; text-align: left; float: right;">Ahmad Suroso</div>

        </div>
    <?php } ?>
    </body>
    <script>
        window.print();
    </script>

    </html>