<?php

include "../../lib/koneksi.php";

$nomer = $_POST['nomer'];
$no_kk = $_POST['no_kk'];
$nik = $_POST['nik'];
$status = $_POST['status'];


mysqli_query($koneksi, " UPDATE tbl_anggota_kk SET no_kk ='$no_kk', nik ='$nik', status ='$status' WHERE nomer='$nomer' ");

header("location:main.php");
