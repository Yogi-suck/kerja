<?php
include "../../header.php";
?>
<!-- Main Content -->
<div class="container-fluid">
  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Edit Data Anggota KK</h4>
            <div class="card-header-action">
              <a href="<?php echo $baseUrl; ?>/pages/anggota_kk/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data Anggota KK </a>
            </div>
          </div>
          <div class="card-body p-0">

            <?php
            include '../../lib/koneksi.php';
            $nomer = $_GET['nomer'];
            $data = mysqli_query($koneksi, "select * from tbl_anggota_kk where nomer='$nomer'");
            while ($q = mysqli_fetch_array($data)) {
            ?>

              <div class="card-body">
                <div class="section-title mt-0">Text</div>

                <form action="simpan_edit.php" method="POST">
                  <input type="hidden" name="nomer" value="<?php echo $q['nomer']; ?>">

                  <div class="form-group">
                    <label>Nomer Anggota KK</label>
                    <input type="text" class="form-control" name="nomer" value="<?= $q['nomer']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Nomer Kartu Keluarga </label>
                    <input type="text" class="form-control" name="no_kk" value="<?= $q['no_kk']; ?>">
                  </div>
                  <div class="form-group">
                    <label>NIK</label>
                    <input type="text" class="form-control" name="nik" value="<?= $q['nik']; ?>">
                  </div>
                  <div class="form-group">
                    <label>status</label>
                    <select class="form-control form-control-user" name='status'>
                      <option <?php echo ($q['status'] == 'Masyarakat Asli Penungkulan') ? "selected" : "" ?> value='Masyarakat Asli Penungkulan'>Masyarakat Asli Penungkulan</option>
                      <option <?php echo ($q['status'] == 'Masyarakat Bukan Asli Penungkulan') ? "selected" : "" ?> value='Masyarakat Bukan Asli Penungkulan'>Masyarakat Bukan Asli Penungkulan</option>
                    </select>
                  </div>


                  <div class="card-footer text-right">
                    <button onclick="return confirm('Apakah anda yakin ingin mengganti data ini ?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  </div>
                </form>
              <?php } ?>
              </div>
          </div>
        </div>
      </div>
  </section>
</div>


<?php
include "../../footer.php";
?>