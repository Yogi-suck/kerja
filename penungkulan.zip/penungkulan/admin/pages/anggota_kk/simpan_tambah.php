<?php

include "../../lib/koneksi.php";

$nomer = $_POST['nomer'];
$no_kk = $_POST['no_kk'];
$nik = $_POST['nik'];
$status = $_POST['status'];

mysqli_query($koneksi, "INSERT INTO tbl_anggota_kk (nomer, no_kk, nik, status) VALUES ('$nomer', '$no_kk', '$nik', '$status')");

header("location:main.php");
