<?php
include "../../header.php";
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"> Surat</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"> Surat</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nama Penduduk</th>
                            <th>Nomer Induk Kependudukan</th>
                            <th>Surat Pengantar Pembuatan Skck</th>
                            <th>Surat Pengantar Pembuatan KK</th>
                            <th>Surat Pengantar Pembuatan e-Ktp</th>
                            <th>Surat Keterangan Tidak Mampu</th>
                            <th>Surat Pengantar Nikah</th>
                            <th>Surat Pengantar Domisili</th>
                            <th>Surat Pengantar Pembuatan BPJS</th>
                        </tr>
                    </thead>


                    <tbody>
                        <?php
                        if ($_SESSION['level'] == 'A') {
                            $sql = mysqli_query($koneksi, "SELECT * FROM tbl_penduduk");
                        } else {
                            $nik = $_SESSION['nik'];
                            $sql = mysqli_query($koneksi, "SELECT * FROM tbl_penduduk WHERE nik = '$nik'");
                        }
                        while ($data = mysqli_fetch_array($sql)) {
                        ?>
                            <tr>
                                <td><?php echo $data['nama_penduduk'] ?></a></td>
                                <td><?php echo $data['nik'] ?></a></td>
                                <td><a href="<?= $baseUrl; ?>../pages/surat/skck.php?nik=<?= $data['nik']; ?>">Cetak Surat</a></td>
                                <td><a href="<?= $baseUrl; ?>../pages/surat/buat_kk.php?nik=<?= $data['nik']; ?>">Cetak Surat</a></td>
                                <td><a href="<?= $baseUrl; ?>../pages/surat/buat_ktp.php?nik=<?= $data['nik']; ?>">Cetak Surat</a></td>
                                <td><a href="<?= $baseUrl; ?>../pages/surat/sktm.php?nik=<?= $data['nik']; ?>">Cetak Surat</a></td>
                                <td><a href="<?= $baseUrl; ?>../pages/surat/nikah.php?nik=<?= $data['nik']; ?>">Cetak Surat</a></td>
                                <td><a href="<?= $baseUrl; ?>../pages/surat/domisili.php?nik=<?= $data['nik']; ?>">Cetak Surat</a></td>
                                <td><a href="<?= $baseUrl; ?>../pages/surat/bpjs.php?nik=<?= $data['nik']; ?>">Cetak Surat</a></td>
                            </tr>

                        <?php } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
include "../../footer.php";
?>