<?php
include '../../lib/koneksi.php';
$nik = $_GET['nik'];
$data = mysqli_query($koneksi, "select * from tbl_penduduk where nik='$nik'");
while ($q = mysqli_fetch_array($data)) {
?>

    <!DOCTYPE html>

    <head>
        <title>SURAT PENGANTAR PEMBUATAN SKCK</title>
        <meta charset="utf-8">
        <style>
            #judul {
                text-align: center;
            }

            #halaman {
                width: auto;
                height: auto;
                position: absolute;
                border: 1px solid;
                padding-top: 30px;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 80px;
            }
        </style>

    </head>

    <body>
        <div id=halaman>
            <h3 id=judul>PEMERINTAHAN KABUPATEN PURWOREJO</h3>
            <h3 id=judul>KECAMATAN GEBANG</h3>
            <h3 id=judul>DESA PENUNGKULAN</h3>
            <hr>
            <h3 id=judul>SURAT PENGANTAR SKCK</h3>

            <p>Dengan hormat</p>
            <p>Yang bertandatangan dibawah ini Kepala Desa Penungkulan Kecamatan Gebang Kabupaten Purworejo, <br>menerangkan bahwa :</p>

            <table>
                <tr>
                    <td style="width: 30%;">Nama</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nama_penduduk']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">NIK</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Tempat Lahir</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['tmptlahir']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Tanggal Lahir</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['tgllahir']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Jenis Kelamin</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['jenis_kelamin']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Agama</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['agama']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Pekerjaan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kd_pekerjaan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Setatus Perkawinan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['statusperkawinan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Perdukuhan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kd_perdukuhan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">RT</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['rt']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Rw</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['rw']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Desa</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['desa']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Kecamatan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kecamatan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Kabupaten</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kabupaten']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Provinsi</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['provinsi']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Kode Pos</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['kodepos']; ?></td>
                </tr>
            </table>

            <p>Sepanjang dalam sepengetahuan kami orang tersebut diatas berkelakuan baik, dan tidak terlibat dalam tindakan kriminal.</p>
            <p>Orang tersebut diatas bermaksud membuat SKCK , untuk memenuhi persyaratan :</p>
            <h3 id=judul>“ MELAMAR PEKERJAAN “</h3>
            <p>Demikian surat pengantar ini dibuat untuk dapat dipergunakan sebagaimana mestinya .</p>

            <div style="width: 50%; text-align: left; float: right;">Purowrejo, <?php echo date('d F Y') ?></div><br>
            <div style="width: 50%; text-align: left; float: right;">Yang bertanda tangan,</div><br><br><br><br><br>
            <div style="width: 50%; text-align: left; float: right;">Ahmad Suroso</div>

        </div>
    <?php } ?>
    </body>
    <script>
        window.print();
    </script>

    </html>