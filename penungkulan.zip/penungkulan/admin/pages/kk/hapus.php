<?php
include "../../lib/koneksi.php";

$no_kk = $_GET['no_kk'];
mysqli_query($koneksi, "DELETE FROM tbl_kk WHERE no_kk='$no_kk'");

header("location:main.php");
