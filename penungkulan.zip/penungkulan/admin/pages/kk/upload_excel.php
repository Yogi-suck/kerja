<?php
// menghubungkan dengan koneksi
include '../../lib/koneksi.php';
// menghubungkan dengan library excel reader
include "../../lib/excel_reader2.php";

// upload file xls
$target = basename($_FILES['import']['name']);
move_uploaded_file($_FILES['import']['tmp_name'], $target);

// beri permisi agar file xls dapat di baca
chmod($_FILES['import']['name'], 0777);

// mengambil isi file xls
$data = new Spreadsheet_Excel_Reader($_FILES['import']['name'], false);
// menghitung jumlah baris data yang ada
$jumlah_baris = $data->rowcount($sheet_index = 0);

// jumlah default data yang berhasil di import
$berhasil = 0;
for ($i = 3; $i <= $jumlah_baris; $i++) {
	// menangkap data dan memasukkan ke variabel sesuai dengan kolumnya masing-masing
	$kk = $data->val($i, 3);
	$nik = $data->val($i, 4);

	if ($nik != "" && $kk != "") {
		mysqli_query($koneksi, "INSERT INTO tbl_kk VALUES ('$kk','$nik')");
		$berhasil++;
	}
}

// hapus kembali file .xls yang di upload tadi
unlink($_FILES['import']['name']);

// alihkan halaman ke index.php
header("location:main.php");
