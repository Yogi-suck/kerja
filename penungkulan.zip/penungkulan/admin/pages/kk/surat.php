<?php
include '../../lib/koneksi.php';
$no_kk = $_GET['no_kk'];
$data = mysqli_query($koneksi, "select * from tbl_kk where no_kk='$no_kk'");
while ($q = mysqli_fetch_array($data)) {
?>

    <!DOCTYPE html>

    <head>
        <title>SURAT KETERANGAN KEPALA KELUARGA</title>
        <meta charset="utf-8">
        <style>
            #judul {
                text-align: center;
            }

            #halaman {
                width: auto;
                height: auto;
                position: absolute;
                border: 1px solid;
                padding-top: 30px;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 80px;
            }
        </style>

    </head>

    <body>
        <div id=halaman>
            <h3 id=judul>SURAT KETERANGAN KEPALA KELUARGA</h3>

            <p>Data Kepala Keluarga :</p>

            <table>
                <tr>
                    <td style="width: 30%;">Nik Kepala Keluarga</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik_kepala_keluarga']; ?></td>
                </tr>
            </table>

            <p>Data tersebut merupakan data kepala keluarga.</p>

            <div style="width: 50%; text-align: left; float: right;">Purowrejo, 25 Februari 2022</div><br>
            <div style="width: 50%; text-align: left; float: right;">Yang bertanda tangan,</div><br><br><br><br><br>
            <div style="width: 50%; text-align: left; float: right;">Ahmad Suroso</div>

        </div>
    <?php } ?>
    </body>
    <script>
        window.print();
    </script>

    </html>