<?php

include "../../lib/koneksi.php";

$no_kk = $_POST['no_kk'];
$nik = $_POST['nik'];

mysqli_query($koneksi, "UPDATE tbl_kk SET nik='$nik' WHERE no_kk='$no_kk'");

header("location:main.php");
