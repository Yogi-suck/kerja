<?php

include "../../lib/koneksi.php";

$no_kk = $_POST['no_kk'];
$nik = $_POST['nik'];

mysqli_query($koneksi, "INSERT INTO tbl_kk (no_kk, nik) VALUES ('$no_kk', '$nik')");

header("location:main.php");
