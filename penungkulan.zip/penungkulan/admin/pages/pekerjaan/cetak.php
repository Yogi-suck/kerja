<html>

<head>
  <title>DATA PEKERJAAN PENUNGKULAN</title>
</head>

<body>

  <?php session_start();

  include "../../lib/koneksi.php";
  ?>

  <div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header">
              <h4>Data Pekerjaan</h4>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive table-invoice">
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pekerjaan");


                ?>
                <table class="table table-striped">
                  <tr>
                    <th>Kode Pekerjaan</th>
                    <th>Nama Pekerjaan</th>
                  </tr>
                  <?php
                  while ($data = mysqli_fetch_array($sql)) {
                  ?>
                    <tr>
                      <td><?php echo $data['kd_pekerjaan'] ?></a></td>
                      <td><?php echo $data['nama_pekerjaan'] ?></a></td>
                    </tr>

                  <?php } ?>

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script>
    window.print();
  </script>

</body>

</html>