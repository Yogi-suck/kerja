<?php

include "../../lib/koneksi.php";

$kd_pekerjaan = $_POST['kd_pekerjaan'];
$nama_pekerjaan = $_POST['nama_pekerjaan'];

mysqli_query($koneksi, "INSERT INTO tbl_pekerjaan (kd_pekerjaan, nama_pekerjaan) VALUES ('$kd_pekerjaan', '$nama_pekerjaan')");

header("location:main.php");
