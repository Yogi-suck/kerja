<?php

include "../../lib/koneksi.php";

$kd_pekerjaan = $_POST['kd_pekerjaan'];
$nama_pekerjaan = $_POST['nama_pekerjaan'];

mysqli_query($koneksi, " UPDATE tbl_pekerjaan SET nama_pekerjaan = '$nama_pekerjaan' WHERE kd_pekerjaan = '$kd_pekerjaan' ");

header("location:main.php");
