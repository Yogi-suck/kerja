<?php
include "../../header.php";
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Data Pekerjaan</h1>

    <?php
    $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pekerjaan");

    ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Pekerjaan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div>
                    <a href="<?php echo $baseUrl; ?>/pages/pekerjaan/form_tambah.php" class="btn btn-danger">Tambah Data Pekerjaan<i class="fas fa-chevron-right"></i></a>
                </div>
                <hr>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Kode Pekerjaan</th>
                            <th>Nama Pekerjaan</th>
                            <th>Action</th>
                        </tr>
                    </thead>


                    <tbody>
                        <?php
                        while ($data = mysqli_fetch_array($sql)) {
                        ?>
                            <tr>
                                <td><?php echo $data['kd_pekerjaan'] ?></a></td>
                                <td><?php echo $data['nama_pekerjaan'] ?></a></td>
                                <td class="text-nowrap">
                                    <a href="<?= $baseUrl; ?>../pages/pekerjaan/form_edit.php?kd_pekerjaan=<?= $data['kd_pekerjaan']; ?>" class="btn btn-primary">Memperbaharui</a>
                                    <a href="<?= $baseUrl; ?>../pages/pekerjaan/hapus.php?kd_pekerjaan=<?= $data['kd_pekerjaan']; ?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini ?')" class="btn btn-danger">Hapus</a>
                                    <a href="<?= $baseUrl; ?>../pages/pekerjaan/surat.php?kd_pekerjaan=<?= $data['kd_pekerjaan']; ?>" class="btn btn-primary">Cetak Surat</a>
                                </td>
                            </tr>

                        <?php } ?>

                    </tbody>
                </table>
            </div>
            <a href="<?php echo $baseUrl; ?>/pages/pekerjaan/cetak.php" class="btn btn-primary mt-3" target="_BLANK"><i class="fas fa-print"></i> CETAK DATA</a>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
include "../../footer.php";
?>