<?php
include "../../lib/koneksi.php";

$kd_pekerjaan = $_GET['kd_pekerjaan'];
mysqli_query($koneksi, "DELETE FROM tbl_pekerjaan WHERE kd_pekerjaan='$kd_pekerjaan'");

header("location:main.php");
