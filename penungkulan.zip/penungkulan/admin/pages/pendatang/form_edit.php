<?php
include "../../header.php";
?>

<!-- Main Content -->
<div class="container-fluid">
  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Edit Data Pendatang</h4>
            <div class="card-header-action">
              <a href="<?php echo $baseUrl; ?>/pages/pendatang/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data Pendatang</a>
            </div>
          </div>
          <div class="card-body p-0">

            <?php
            include '../../lib/koneksi.php';
            $nik = $_GET['nik'];
            $data = mysqli_query($koneksi, "select * from tbl_pendatang_baru where nik='$nik'");
            while ($q = mysqli_fetch_array($data)) {
            ?>

              <div class="card-body">

                <form action="simpan_edit.php" method="POST">
                  <div class="form-group">
                    <label>Nomer KK</label>
                    <input type="text" class="form-control" name="kk" value="<?= $q['kk']; ?>"readonly>
                  </div>
                  <div class="form-group">
                    <label>Nomer Induk Kependudukan</label>
                    <input type="text" class="form-control" name="nik" value="<?= $q['nik']; ?>"readonly>
                  </div>
                  <div class="form-group">
                    <label>Nama Penduduk</label>
                    <input type="text" class="form-control" name="nama_penduduk" value="<?= $q['nama_penduduk']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Alamat Asal</label>
                    <input type="text" class="form-control" name="alamat_asal" value="<?= $q['alamat_asal']; ?>">
                  </div>

                  <div class="form-group">
                  <label>Perdukuhan </label>
                  <?php $sql = mysqli_query($koneksi, "SELECT * FROM tbl_perdukuhan"); ?>
                  <select class="form-control form-control-user" id="kd_perdukuhan" name="kd_perdukuhan" placeholder="Nomer KK">
                    <?php while ($data_perdukuhan = mysqli_fetch_array($sql)) { ?>
                      <option value='<?= $data_perdukuhan['kd_perdukuhan'] ?>' <?php echo ($q['kd_perdukuhan'] == $data_perdukuhan['kd_perdukuhan']) ? "selected" : "" ?>>
                        <?= $data_perdukuhan['kd_perdukuhan'] ?> - <?= $data_perdukuhan['nama_perdukuhan'] ?>
                          
                        </option>
                    <?php } ?>
                  </select>
                </div>

                  <div class="form-group">
                    <label>RT</label>
                    <select class="form-control form-control-user" name='rt'>
                      <option <?php echo ($q['rt'] == '1') ? "selected" : "" ?> value='1'>1</option>
                      <option <?php echo ($q['rt'] == '2') ? "selected" : "" ?> value='2'>2</option>
                      <option <?php echo ($q['rt'] == '3') ? "selected" : "" ?> value='3'>3</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Rw</label>
                    <select class="form-control form-control-user" name='rw'>
                      <option <?php echo ($q['rw'] == '1') ? "selected" : "" ?> value='1'>1</option>
                      <option <?php echo ($q['rw'] == '2') ? "selected" : "" ?> value='2'>2</option>
                      <option <?php echo ($q['rw'] == '3') ? "selected" : "" ?> value='3'>3</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Desa</label>
                    <input type="text" class="form-control" name="desa" value="<?= $q['desa']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Kecamatan</label>
                    <input type="text" class="form-control" name="kecamatan" value="<?= $q['kecamatan']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Kabupaten</label>
                    <input type="text" class="form-control" name="kabupaten" value="<?= $q['kabupaten']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Provinsi</label>
                    <input type="text" class="form-control" name="provinsi" value="<?= $q['provinsi']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Kode Pos</label>
                    <input type="text" class="form-control" name="kodepos" value="<?= $q['kodepos']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input type="text" class="form-control" name="tmptlahir" value="<?= $q['tmptlahir']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input type="date" class="form-control" name="tgllahir" value="<?= date('Y-m-d', strtotime($q['tgllahir'])); ?>">
                  </div>
                  <div class="form-group">
                    <label>Agama</label>
                    <select class="form-control form-control-user" name='agama'>
                      <option <?php echo ($q['agama'] == 'islam') ? "selected" : "" ?> value='islam'>islam</option>
                      <option <?php echo ($q['agama'] == 'kristen') ? "selected" : "" ?> value='kristen'>kristen</option>
                      <option <?php echo ($q['agama'] == 'katholik') ? "selected" : "" ?> value='katholik'>katholik</option>
                      <option <?php echo ($q['agama'] == 'hindu') ? "selected" : "" ?> value='hindu'>hindu</option>
                      <option <?php echo ($q['agama'] == 'budha') ? "selected" : "" ?> value='budha'>budha</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Status Perkawinan</label>
                    <select class="form-control form-control-user" name='statusperkawinan'>
                      <option <?php echo ($q['statusperkawinan'] == 'Belum kawin') ? "selected" : "" ?> value='Belum kawin'>Belum kawin</option>
                      <option <?php echo ($q['statusperkawinan'] == 'Kawin') ? "selected" : "" ?> value='Kawin'>Kawin</option>
                      <option <?php echo ($q['statusperkawinan'] == 'Cerai hidup') ? "selected" : "" ?> value='Cerai hidup'>Cerai hidup</option>
                      <option <?php echo ($q['statusperkawinan'] == 'Cerai mati') ? "selected" : "" ?> value='Cerai mati'>Cerai mati</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Hubungan Keluarga</label>
                    <select class="form-control form-control-user" name='statushubkeluarga'>
                      <option <?php echo ($q['statushubkeluarga'] == 'Kepala Keluarga') ? "selected" : "" ?> value='Kepala Keluarga'>Kepala Keluarga</option>
                      <option <?php echo ($q['statushubkeluarga'] == 'Suami') ? "selected" : "" ?> value='Suami'>Suami</option>
                      <option <?php echo ($q['statushubkeluarga'] == 'Istri') ? "selected" : "" ?> value='Istri'>Istri</option>
                      <option <?php echo ($q['statushubkeluarga'] == 'Anak') ? "selected" : "" ?> value='Anak'>Anak</option>
                      <option <?php echo ($q['statushubkeluarga'] == 'Menantu') ? "selected" : "" ?> value='Menantu'>Menantu</option>
                      <option <?php echo ($q['statushubkeluarga'] == 'Cucu') ? "selected" : "" ?> value='Cucu'>Cucu</option>
                      <option <?php echo ($q['statushubkeluarga'] == 'Orang Tua') ? "selected" : "" ?> value='Orang Tua'>Orang Tua</option>
                      <option <?php echo ($q['statushubkeluarga'] == 'Mertua') ? "selected" : "" ?> value='Mertua'>Mertua</option>
                      <option <?php echo ($q['statushubkeluarga'] == 'Pembantu') ? "selected" : "" ?> value='Pembantu'>Pembantu</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label>Pekerjaan</label>
                  <?php $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pekerjaan"); ?>
                  <select class="form-control form-control-user" id="kd_pekerjaan" name="kd_pekerjaan" placeholder="Nomer KK">
                    <?php while ($data_pekerjaan = mysqli_fetch_array($sql)) { ?>
                      <option value='<?= $data_pekerjaan['kd_pekerjaan'] ?>' <?php echo ($q['kd_pekerjaan'] == $data_pekerjaan['kd_pekerjaan']) ? "selected" : "" ?>>
                        <?= $data_pekerjaan['kd_pekerjaan'] ?> - <?= $data_pekerjaan['nama_pekerjaan'] ?>
                        </option>
                    <?php } ?>
                  </select>
                </div>

                  <div class="form-group">
                  <label>Pendidikan</label>
                  <?php $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pendidikan"); ?>
                  <select class="form-control form-control-user" id="kd_pendidikan" name="kd_pendidikan" placeholder="Nomer KK">
                    <?php while ($data_pendidikan = mysqli_fetch_array($sql)) { ?>
                      <option value='<?= $data_pendidikan['kd_pendidikan'] ?>' <?php echo ($q['kd_pendidikan'] == $data_pendidikan['kd_pendidikan']) ? "selected" : "" ?>>
                        <?= $data_pendidikan['kd_pendidikan'] ?> - <?= $data_pendidikan['nama_pendidikan'] ?>
                        </option>
                    <?php } ?>
                  </select>
                </div>

                  <div class="form-group">
                    <label>Golongan Darah</label>
                    <select class="form-control form-control-user" name='gol_darah'>
                      <option <?php echo ($q['gol_darah'] == 'A') ? "selected" : "" ?> value='A'>A</option>
                      <option <?php echo ($q['gol_darah'] == 'B') ? "selected" : "" ?> value='B'>B</option>
                      <option <?php echo ($q['gol_darah'] == 'O') ? "selected" : "" ?> value='O'>O</option>
                      <option <?php echo ($q['gol_darah'] == 'AB') ? "selected" : "" ?> value='AB'>AB</option>
                      <option <?php echo ($q['gol_darah'] == 'Belum Mengetahui') ? "selected" : "" ?> value='Belum Mengetahui'>Belum Mengetahui</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Status Kwarganegaraan</label>
                    <input type="text" class="form-control" name="status_kewarganegaraan" value="<?= $q['status_kewarganegaraan']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select class="form-control form-control-user" name='jenis_kelamin'>
                      <option <?php echo ($q['jenis_kelamin'] == 'Laki-Laki') ? "selected" : "" ?> value='Laki-Laki'>Laki-Laki</option>
                      <option <?php echo ($q['jenis_kelamin'] == 'Perempuan') ? "selected" : "" ?> value='Perempuan'>Perempuan</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Nama Orang Tua</label>
                    <input type="text" class="form-control" name="nama_ayah" value="<?= $q['nama_ayah']; ?>">
                  </div>

                  <div class="card-footer text-right">
                    <button onclick="return confirm('Apakah anda yakin ingin mengganti data ini ?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  </div>
                </form>
              <?php } ?>
              </div>
          </div>
        </div>
      </div>
  </section>
</div>



<?php
include "../../footer.php";
?>