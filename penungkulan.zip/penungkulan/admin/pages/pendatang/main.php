<?php
include "../../header.php";
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Data Pendatang</h1>


    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Pendatang</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div>
                    <a href="<?php echo $baseUrl; ?>/pages/pendatang/form_tambah.php" class="btn btn-danger">Tambah Data Pendatang <i class="fas fa-chevron-right"></i></a>
                    <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-info"><i class="fas fa-upload"></i> Impor Data Pendatang</button>

                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Impor Data Pendatang</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form method="POST" enctype="multipart/form-data" action="upload_excel.php">
                                    <div class="modal-body">

                                        <div class="form-group">
                                            <label for="import">Data Excel</label>
                                            <input type="file" class="form-control-file" name="import" id="import">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                        <button type="submit" class="btn btn-primary">Impor</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nomer KK</th>
                            <th>Nomer Induk Kependudukan</th>
                            <th>Nama Penduduk</th>
                            <th>Alamat Asal</th>
                            <th>Perdukuhan</th>
                            <th>RT</th>
                            <th>Rw</th>
                            <th>Desa</th>
                            <th>Kecamatan</th>
                            <th>Kabupaten</th>
                            <th>Provinsi</th>
                            <th>Kode Pos</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Agama</th>
                            <th>Setatus Perkawinan</th>
                            <th>Hubungan Keluarga</th>
                            <th>Pekerjaan</th>
                            <th>Pendidikan</th>
                            <th>Golongan Darah</th>
                            <th>Setatus kwarganegaraan</th>
                            <th>Jenis Kelamin</th>
                            <th>Nama Ayah</th>
                            <th>Action</th>
                        </tr>
                    </thead>


                    <tbody>
                        <?php
                        if ($_SESSION['level'] == 'A') {
                            $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pendatang_baru");
                        } else {
                            $nik = $_SESSION['nik'];
                            $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pendatang_baru WHERE nik = '$nik'");
                        }
                        while ($data = mysqli_fetch_array($sql)) {
                        ?>
                            <tr>
                                <td><?php echo $data['kk'] ?></a></td>
                                <td><?php echo $data['nik'] ?></a></td>
                                <td><?php echo $data['nama_penduduk'] ?></a></td>
                                <td><?php echo $data['alamat_asal'] ?></a></td>
                                <td><?php echo $data['kd_perdukuhan'] ?></a></td>
                                <td><?php echo $data['rt'] ?></td>
                                <td><?php echo $data['rw'] ?></td>
                                <td><?php echo $data['desa'] ?></td>
                                <td><?php echo $data['kecamatan'] ?></td>
                                <td><?php echo $data['kabupaten'] ?></td>
                                <td><?php echo $data['provinsi'] ?></td>
                                <td><?php echo $data['kodepos'] ?></td>
                                <td><?php echo $data['tmptlahir'] ?></td>
                                <td><?php echo $data['tgllahir'] ?></td>
                                <td><?php echo $data['agama'] ?></td>
                                <td><?php echo $data['statusperkawinan'] ?></td>
                                <td><?php echo $data['statushubkeluarga'] ?></td>
                                <td><?php echo $data['kd_pekerjaan'] ?></td>
                                <td><?php echo $data['kd_pendidikan'] ?></td>
                                <td><?php echo $data['gol_darah'] ?></td>
                                <td><?php echo $data['status_kewarganegaraan'] ?></td>
                                <td><?php echo $data['jenis_kelamin'] ?></td>
                                <td><?php echo $data['nama_ayah'] ?></td>
                                <td class="text-nowrap">
                                    <a href="<?= $baseUrl; ?>/pages/pendatang/form_edit.php?nik=<?= $data['nik']; ?>" class="btn btn-primary">Memperbaharui</a>
                                    <a href="<?= $baseUrl; ?>/pages/pendatang/hapus.php?nik=<?= $data['nik']; ?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini ?')" class="btn btn-danger">Hapus</a>
                                    <a href="<?= $baseUrl; ?>/pages/pendatang/surat.php?nik=<?= $data['nik']; ?>" class="btn btn-primary">Cetak Surat</a>
                                </td>
                            </tr>

                        <?php } ?>

                    </tbody>
                </table>
            </div>

            <a href="<?php echo $baseUrl; ?>/pages/pendatang/cetak.php" class="btn btn-primary mt-3" target="_BLANK"><i class="fas fa-print"></i> CETAK DATA</a>

        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
include "../../footer.php";
?>