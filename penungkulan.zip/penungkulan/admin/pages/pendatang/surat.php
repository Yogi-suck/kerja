<?php
include '../../lib/koneksi.php';
$no_pendatang = $_GET['no_pendatang'];
$data = mysqli_query($koneksi, "select * from tbl_pendatang where no_pendatang='$no_pendatang'");
while ($q = mysqli_fetch_array($data)) {
?>

    <!DOCTYPE html>

    <head>
        <title>SURAT KETERANGAN PENDATANG</title>
        <meta charset="utf-8">
        <style>
            #judul {
                text-align: center;
            }

            #halaman {
                width: auto;
                height: auto;
                position: absolute;
                border: 1px solid;
                padding-top: 30px;
                padding-left: 30px;
                padding-right: 30px;
                padding-bottom: 80px;
            }
        </style>

    </head>

    <body>
        <div id=halaman>
            <h3 id=judul>SURAT KETERANGAN PENDATANG</h3>

            <p>Data pendatang :</p>

            <table>
                <tr>
                    <td style="width: 30%;">Nik</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nik Kepala Keluarga</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nik_kepala_keluarga']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Nama</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['nama']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Tanggal</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['tanggal']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Alamat Asal</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['alamat_asal']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">Alamat Tujuan</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['alamat_tujuan']; ?></td>
                </tr>
                <tr>
                    <td style="width: 30%;">status</td>
                    <td style="width: 5%;">:</td>
                    <td style="width: 65%;"><?= $q['status']; ?></td>
                </tr>
            </table>

            <p>Data tersebut merupakan data pendatang.</p>

            <div style="width: 50%; text-align: left; float: right;">Purowrejo, 25 Februari 2022</div><br>
            <div style="width: 50%; text-align: left; float: right;">Yang bertanda tangan,</div><br><br><br><br><br>
            <div style="width: 50%; text-align: left; float: right;">Ahmad Suroso</div>

        </div>
    <?php } ?>
    </body>
    <script>
        window.print();
    </script>

    </html>