<?php

include "../../lib/koneksi.php";

$kk = $_POST['kk'];
$nik = $_POST['nik'];
$nama_penduduk = $_POST['nama_penduduk'];
$alamat_asal = $_POST['alamat_asal'];
$kd_perdukuhan = $_POST['kd_perdukuhan'];
$rt = $_POST['rt'];
$rw = $_POST['rw'];
$desa = $_POST['desa'];
$kecamatan = $_POST['kecamatan'];
$kabupaten = $_POST['kabupaten'];
$provinsi = $_POST['provinsi'];
$kodepos = $_POST['kodepos'];
$tmptlahir = $_POST['tmptlahir'];
$tgllahir = $_POST['tgllahir'];
$agama = $_POST['agama'];
$statusperkawinan = $_POST['statusperkawinan'];
$statushubkeluarga = $_POST['statushubkeluarga'];
$kd_pekerjaan = $_POST['kd_pekerjaan'];
$kd_pendidikan = $_POST['kd_pendidikan'];
$gol_darah = $_POST['gol_darah'];
$status_kewarganegaraan = $_POST['status_kewarganegaraan'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$nama_ayah = $_POST['nama_ayah'];


$penduduk = mysqli_query($koneksi, "UPDATE tbl_penduduk SET kk = '$kk', nik='$nik', nama_penduduk='$nama_penduduk', kd_perdukuhan='$kd_perdukuhan', rt='$rt', rw='$rw', desa='$desa', kecamatan='$kecamatan', kabupaten='$kabupaten', provinsi='$provinsi', kodepos='$kodepos', tmptlahir='$tmptlahir', tgllahir='$tgllahir', agama='$agama', statusperkawinan='$statusperkawinan', statushubkeluarga='$statushubkeluarga', kd_pekerjaan='$kd_pekerjaan', kd_pendidikan='$kd_pendidikan', gol_darah='$gol_darah', status_kewarganegaraan='$status_kewarganegaraan', jenis_kelamin='$jenis_kelamin', nama_ayah='$nama_ayah' WHERE nik='$nik'");


$pedatang = mysqli_query($koneksi, "UPDATE tbl_pendatang_baru SET kk = '$kk', nik='$nik', nama_penduduk='$nama_penduduk', alamat_asal='$alamat_asal', kd_perdukuhan='$kd_perdukuhan', rt='$rt', rw='$rw', desa='$desa', kecamatan='$kecamatan', kabupaten='$kabupaten', provinsi='$provinsi', kodepos='$kodepos', tmptlahir='$tmptlahir', tgllahir='$tgllahir', agama='$agama', statusperkawinan='$statusperkawinan', statushubkeluarga='$statushubkeluarga', kd_pekerjaan='$kd_pekerjaan', kd_pendidikan='$kd_pendidikan', gol_darah='$gol_darah', status_kewarganegaraan='$status_kewarganegaraan', jenis_kelamin='$jenis_kelamin', nama_ayah='$nama_ayah' WHERE nik='$nik'");

header("location:main.php");
