<html>

<head>
  <title>DATA PENDUDUK PENDATANG PENUNGKULAN</title>
</head>

<body>

  <?php session_start();

  include "../../lib/koneksi.php";
  ?>

  <div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header">
              <h4>Data Pendatang</h4>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive table-invoice">
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pendatang");
                ?>
                <table class="table table-striped">
                  <tr>
                    <th>Nomer Pendatang</th>
                    <th> Pendatang</th>
                    <th>Nik Kepala Keluarga</th>
                    <th>Nama</th>
                    <th>Tanggal</th>
                    <th>Alamat Asal</th>
                    <th>Alamat Tujuan</th>
                    <th>status</th>
                  </tr>
                  <?php
                  while ($data = mysqli_fetch_array($sql)) {
                  ?>
                    <tr>
                      <td><?php echo $data['no_pendatang'] ?></a></td>
                      <td><?php echo $data['nik'] ?></a></td>
                      <td><?php echo $data['nik_kepala_keluarga'] ?></a></td>
                      <td><?php echo $data['nama'] ?></td>
                      <td><?php echo $data['tanggal'] ?></td>
                      <td><?php echo $data['alamat_asal'] ?></td>
                      <td><?php echo $data['alamat_tujuan'] ?></td>
                      <td><?php echo $data['status'] ?></td>
                    </tr>

                  <?php } ?>

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script>
    window.print();
  </script>

</body>

</html>