<?php

include "../../lib/koneksi.php";

$kk = $_POST['kk'];
$nik = $_POST['nik'];
$nama_penduduk = $_POST['nama_penduduk'];
$alamat_asal = $_POST['alamat_asal'];
$kd_perdukuhan = $_POST['kd_perdukuhan'];
$rt = $_POST['rt'];
$rw = $_POST['rw'];
$desa = 'PENUNGKULAN';
$kecamatan = 'GEBANG';
$kabupaten = 'PURWOREJO';
$provinsi = 'JAWA TENGAH';
$kodepos = '54191';
$tmptlahir = $_POST['tmptlahir'];
$tgllahir = $_POST['tgllahir'];
$agama = $_POST['agama'];
$statusperkawinan = $_POST['statusperkawinan'];
$statushubkeluarga = $_POST['statushubkeluarga'];
$kd_pekerjaan = $_POST['kd_pekerjaan'];
$kd_pendidikan = $_POST['kd_pendidikan'];
$gol_darah = $_POST['gol_darah'];
$status_kewarganegaraan = $_POST['status_kewarganegaraan'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$nama_ayah = $_POST['nama_ayah'];

mysqli_query($koneksi, "INSERT INTO tbl_pendatang_baru (kk, nik, nama_penduduk, alamat_asal, kd_perdukuhan, rt, rw, desa, kecamatan, kabupaten, provinsi, kodepos, tmptlahir, tgllahir, agama, statusperkawinan, statushubkeluarga, kd_pekerjaan, kd_pendidikan, gol_darah, status_kewarganegaraan, jenis_kelamin, nama_ayah) VALUES ('$kk', '$nik', '$nama_penduduk', '$alamat_asal', '$kd_perdukuhan', '$rt', '$rw', '$desa', '$kecamatan', '$kabupaten', '$provinsi', '$kodepos', '$tmptlahir', '$tgllahir', '$agama', '$statusperkawinan', '$statushubkeluarga', '$kd_pekerjaan', '$kd_pendidikan', '$gol_darah', '$status_kewarganegaraan', '$jenis_kelamin', '$nama_ayah')");

mysqli_query($koneksi, "INSERT INTO tbl_penduduk (kk, nik, nama_penduduk, kd_perdukuhan, rt, rw, desa, kecamatan, kabupaten, provinsi, kodepos, tmptlahir, tgllahir, agama, statusperkawinan, statushubkeluarga, kd_pekerjaan, kd_pendidikan, gol_darah, status_kewarganegaraan, jenis_kelamin, nama_ayah) VALUES ('$kk', '$nik', '$nama_penduduk', '$kd_perdukuhan', '$rt', '$rw', '$desa', '$kecamatan', '$kabupaten', '$provinsi', '$kodepos', '$tmptlahir', '$tgllahir', '$agama', '$statusperkawinan', '$statushubkeluarga', '$kd_pekerjaan', '$kd_pendidikan', '$gol_darah', '$status_kewarganegaraan', '$jenis_kelamin', '$nama_ayah')");


header("location:main.php");
