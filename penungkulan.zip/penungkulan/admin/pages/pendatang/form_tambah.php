<?php
include "../../header.php";
?>
<!-- Main Content -->
<div class="container-fluid">
  <div class="main-content">
    <section class="section">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4>Tambah Data pendatang</h4>
              <div class="card-header-action">
                <a href="<?php echo $baseUrl; ?>/pages/pendatang/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data pendatang</a>
              </div>
            </div>
            <div class="card-body">
              <form action="simpan_tambah.php" method="POST">

                <div class="form-group">
                  <label>Nomer KK</label>
                  <input type="text" class="form-control" name="kk">
                </div>


                <div class="form-group">
                  <label>Nomer Induk Kependudukan</label>
                  <input type="text" class="form-control" name="nik">
                </div>

                <div class="form-group">
                  <label>Nama Penduduk</label>
                  <input type="text" class="form-control" name="nama_penduduk">
                </div>

                <div class="form-group">
                  <label>Alamat Asal</label>
                  <input type="text" class="form-control" name="alamat_asal">
                </div>

                <div class="form-group">
                  <label>Perdukuhan </label>
                  <?php $sql = mysqli_query($koneksi, "SELECT * FROM tbl_perdukuhan"); ?>
                  <select class="form-control form-control-user" id="kd_perdukuhan" name="kd_perdukuhan" placeholder="Nomer KK">
                    <?php while ($data = mysqli_fetch_array($sql)) { ?>
                      <option value='<?= $data['nama_perdukuhan'] ?>'><?= $data['kd_perdukuhan'] ?> - <?= $data['nama_perdukuhan'] ?></option>
                    <?php } ?>
                  </select>
                </div>

                <div class="form-group">
                  <label>RT</label>
                  <select class="form-control form-control-user" id="rt" name="rt" placeholder="Nomer KK">
                    <option value='1'>1</option>
                    <option value='2'>2</option>
                    <option value='3'>3</option>
                  </select>
                </div>

                <div class="form-group">
                  <label>RW</label>
                  <select class="form-control form-control-user" id="rw" name="rw" placeholder="Nomer KK">
                    <option value='1'>1</option>
                    <option value='2'>2</option>
                    <option value='3'>3</option>
                  </select>
                </div>
                
                <div class="form-group">
                  <label>Tempat Lahir</label>
                  <input type="text" class="form-control" name="tmptlahir">
                </div>

                <div class="form-group">
                  <label>Tanggal Lahir</label>
                  <input type="date" class="form-control" name="tgllahir">
                </div>

                <div class="form-group">
                  <label>Agama</label>
                  <select class="form-control form-control-user" id="agama" name="agama" placeholder="Nomer KK">
                    <option value='islam'>Islam</option>
                    <option value='kristen'>Kristen</option>
                    <option value='katholik'>Katholik</option>
                    <option value='hindu'>Hindu</option>
                    <option value='budha'>Budha</option>
                  </select>
                </div>

                <div class="form-group">
                  <label>Status Perkawinan</label>
                  <select class="form-control form-control-user" id="statusperkawinan" name="statusperkawinan" placeholder="Nomer KK">
                    <option value='Belum kawin'>Belum kawin</option>
                    <option value='Kawin'>Kawin</option>
                    <option value='Cerai hidup'>Cerai hidup</option>
                    <option value='Cerai mati'>Cerai mati</option>
                  </select>
                </div>

                <div class="form-group">
                  <label>Hubungan Keluarga</label>
                  <select class="form-control form-control-user" id="statushubkeluarga" name="statushubkeluarga" placeholder="Nomer KK">
                    <option value='Kepala Keluarga'>Kepala Keluarga</option>
                    <option value='Suami'>Suami</option>
                    <option value='Istri'>Istri</option>
                    <option value='Anak'>Anak</option>
                    <option value='Menantu'>Menantu</option>
                    <option value='Cucu'>Cucu</option>
                    <option value='Orang Tua'>Orang Tua</option>
                    <option value='Mertua'>Mertua</option>
                    <option value='Pembantu'>Pembantu</option>
                    <option value='Pendatang'>Pendatang</option>
                  </select>
                </div>

                <div class="form-group">
                  <label>Pekerjaan</label>
                  <?php $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pekerjaan"); ?>
                  <select class="form-control form-control-user" id="kd_pekerjaan" name="kd_pekerjaan" placeholder="Nomer KK">
                    <?php while ($data = mysqli_fetch_array($sql)) { ?>
                      <option value='<?= $data['kd_pekerjaan'] ?>'><?= $data['kd_pekerjaan'] ?> - <?= $data['nama_pekerjaan'] ?></option>
                    <?php } ?>
                  </select>
                </div>

                <div class="form-group">
                  <label>Pendidikan</label>
                  <?php $sql = mysqli_query($koneksi, "SELECT * FROM tbl_pendidikan"); ?>
                  <select class="form-control form-control-user" id="kd_pendidikan" name="kd_pendidikan" placeholder="Nomer KK">
                    <?php while ($data = mysqli_fetch_array($sql)) { ?>
                      <option value='<?= $data['kd_pendidikan'] ?>'><?= $data['kd_pendidikan'] ?> - <?= $data['nama_pendidikan'] ?></option>
                    <?php } ?>
                  </select>
                </div>

                <div class="form-group">
                  <label>Golongan Darah</label>
                  <select class="form-control form-control-user" id="gol_darah" name="gol_darah" placeholder="Nomer KK">
                    <option value='A'>A</option>
                    <option value='B'>B</option>
                    <option value='O'>O</option>
                    <option value='AB'>AB</option>
                    <option value='Belum Mengetahui'>Belum Mengetahui</option>
                  </select>
                </div>

                <div class="form-group">
                  <label>Setatus kwarganegaraan</label>
                  <select class="form-control form-control-user" id="status_kewarganegaraan" name="status_kewarganegaraan" placeholder="Nomer KK">
                    <option value='Warga Negara Indonesia'>Warga Negara Indonesia</option>
                    <option value='Warga Negara Asing'>Warga Negara Asing</option>
                  </select>
                </div>

                <div class="form-group">
                  <label>Jenis Kelamin</label>
                  <select class="form-control form-control-user" id="jenis_kelamin" name="jenis_kelamin" placeholder="Nomer KK">
                    <option value='Laki Laki'>Laki Laki</option>
                    <option value='Perempuan'>Perempuan</option>
                  </select>
                </div>

                <div class="form-group">
                  <label>Nama Orang Tua</label>
                  <input type="text" class="form-control" name="nama_ayah">
                </div>

                <div class="card-footer text-right">
                  <button onclick="return confirm('Apakah anda yakin ingin menambahkan data ini?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  <button onclick="return confirm('Apakah anda yakin ingin mereset data yang sudah di isi?')" class="btn btn-secondary" type="reset">mengatur ulang</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>

<?php
include "../../footer.php";
?>

<script>
  $(document).ready(function() {
    var provinsi = $('#provinsi')
    var kabupaten = $('#kabupaten')
    var kecamatan = $('#kecamatan')
    var desa = $('#desa')

    $.ajax({
      url: 'http://www.emsifa.com/api-wilayah-indonesia/api/provinces.json',
      dataType: 'JSON',
      success: function(data) {
        $.each(data, function(key, value) {
          provinsi.append($('<option>').attr('data-id', value.id).val(value.name).text(value.name))
        });
      }
    });

    provinsi.on('change', function() {
      var idprovinsi = $(this).find('option:selected').data('id');

      if (idprovinsi != undefined) {
        $.ajax({
          url: 'http://www.emsifa.com/api-wilayah-indonesia/api/regencies/' + idprovinsi + '.json',
          dataType: 'JSON',
          success: function(data) {
            $.each(data, function(key, value) {
              kabupaten.append($('<option>').attr('data-id', value.id).val(value.name).text(value.name))
            });
          }
        });
      } else {
        kabupaten.empty()
        kabupaten.append($('<option>').val('').text('Pilih Kabupaten'))
      }
    })

    kabupaten.on('change', function() {
      var idkabupaten = $(this).find('option:selected').data('id');

      if (idkabupaten != undefined) {
        $.ajax({
          url: 'http://www.emsifa.com/api-wilayah-indonesia/api/districts/' + idkabupaten + '.json',
          dataType: 'JSON',
          success: function(data) {
            $.each(data, function(key, value) {
              kecamatan.append($('<option>').attr('data-id', value.id).val(value.name).text(value.name))
            });
          }
        });
      } else {
        kecamatan.empty()
        kecamatan.append($('<option>').val('').text('Pilih Kecamatan'))
      }
    })

    kecamatan.on('change', function() {
      var idkecamatan = $(this).find('option:selected').data('id');

      if (idkecamatan != undefined) {
        $.ajax({
          url: 'http://www.emsifa.com/api-wilayah-indonesia/api/villages/' + idkecamatan + '.json',
          dataType: 'JSON',
          success: function(data) {
            $.each(data, function(key, value) {
              desa.append($('<option>').attr('data-id', value.id).val(value.name).text(value.name))
            });
          }
        });
      } else {
        desa.empty()
        desa.append($('<option>').val('').text('Pilih Desa'))
      }
    })

  });
</script>