<?php

include "../../lib/koneksi.php";

$username = $_POST['username'];
$no_kk = $_POST['no_kk'];
$level = $_POST['level'];
$password = $_POST['password'];

mysqli_query($koneksi, "UPDATE tbl_user SET no_kk='$no_kk', level='$level', password='$password' WHERE username='$username'");

header("location:main.php");
