<?php
include "../../lib/koneksi.php";

$username = $_GET['username'];
mysqli_query($koneksi, "DELETE FROM tbl_user WHERE username='$username'");

header("location:main.php");
