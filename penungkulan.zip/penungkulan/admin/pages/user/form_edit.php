<?php
include "../../header.php";
?>
<!-- Main Content -->
<div class="container-fluid">
  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h4>Edit Data Pengguna</h4>
            <div class="card-header-action">
              <a href="<?php echo $baseUrl; ?>/pages/user/main.php" class="btn btn-danger"><i class="fas fa-chevron-left"></i> Kembali ke Data Pengguna</a>
            </div>
          </div>
          <div class="card-body p-0">

            <?php
            include '../../lib/koneksi.php';
            $username = $_GET['username'];
            $data = mysqli_query($koneksi, "select * from tbl_user where username='$username'");
            while ($q = mysqli_fetch_array($data)) {
            ?>

              <div class="card-body">

                <form action="simpan_edit.php" method="POST">
                  <input type="hidden" name="username" value="<?php echo $q['username']; ?>">

                  <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" name="username" value="<?= $q['username']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Nik</label>
                    <input type="text" class="form-control" name="nik" value="<?= $q['nik']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Level</label>
                    <select class="form-control form-control-user" id="level" name="level" placeholder="Nomer KK">
                      <option value='A'>Perangkat Desa</option>
                      <option value='B'>Masyarakat</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="text" class="form-control" name="password" value="<?= $q['password']; ?>">
                  </div>


                  <div class="card-footer text-right">
                    <button onclick="return confirm('Apakah anda yakin ingin mengganti data ini ?')" class="btn btn-primary mr-1" type="submit">Kirim</button>
                  </div>
                </form>
              <?php } ?>
              </div>
          </div>
        </div>
      </div>
  </section>
</div>


<?php
include "../../footer.php";
?>