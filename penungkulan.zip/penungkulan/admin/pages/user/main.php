<?php
include "../../header.php";
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Data Pengguna</h1>

    <?php
    $sql = mysqli_query($koneksi, "SELECT * FROM tbl_user");

    ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Pengguna</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <hr>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>NIK</th>
                            <th>Password</th>
                            <th>Level</th>
                            <th>Action</th>
                        </tr>
                    </thead>


                    <tbody>
                        <?php
                        while ($data = mysqli_fetch_array($sql)) {
                        ?>
                            <tr>
                                <td><?php echo $data['username'] ?></a></td>
                                <td><?php echo $data['nik'] ?></a></td>
                                <td><?php echo $data['password'] ?></a></td>
                                <td><?php echo $data['level'] ?></a></td>
                                <td class="text-nowrap">
                                    <a href="<?= $baseUrl; ?>../pages/user/form_edit.php?username=<?= $data['username']; ?>" class="btn btn-primary">Memperbaharui</a>
                                    <a href="<?= $baseUrl; ?>../pages/user/hapus.php?username=<?= $data['username']; ?>" onclick="return confirm('Apakah anda yakin ingin menghapus data ini ?')" class="btn btn-danger">Hapus</a>
                                </td>
                            </tr>

                        <?php } ?>

                    </tbody>
                </table>
                <a href="<?php echo $baseUrl; ?>/pages/user/cetak.php" class="btn btn-primary mt-3" target="_BLANK"><i class="fas fa-print"></i> CETAK DATA</a>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
include "../../footer.php";
?>