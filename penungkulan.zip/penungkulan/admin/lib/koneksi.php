<?php 

$baseUrl = 'http://localhost/penungkulan/admin';

$koneksi = mysqli_connect("localhost","root","","penungkulan");

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL". mysqli_connect_errno();
    exit();
}
